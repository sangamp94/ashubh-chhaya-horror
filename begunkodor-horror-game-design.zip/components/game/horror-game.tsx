'use client'

import { useEffect, useRef, useState, useSyncExternalStore } from 'react'
import type { Game } from '@/lib/game/game'
import { hud } from '@/lib/game/hud-store'
import { Hud } from './hud'

export function HorrorGame() {
  const mountRef = useRef<HTMLDivElement>(null)
  const gameRef = useRef<Game | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [ready, setReady] = useState(false)
  const state = useSyncExternalStore(hud.subscribe, hud.getState, hud.getState)

  useEffect(() => {
    let disposed = false
    hud.reset()
    import('@/lib/game/game')
      .then(({ Game }) => {
        if (disposed || !mountRef.current) return
        try {
          gameRef.current = new Game(mountRef.current)
          if (process.env.NODE_ENV === 'development') {
            ;(window as unknown as { __game?: Game }).__game = gameRef.current
          }
          setReady(true)
        } catch (e) {
          setError(e instanceof Error ? e.message : 'WebGL could not start.')
        }
      })
      .catch(() => setError('The station failed to load.'))
    return () => {
      disposed = true
      gameRef.current?.dispose()
      gameRef.current = null
    }
  }, [])

  const begin = () => gameRef.current?.start()

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-black">
      <div
        ref={mountRef}
        className={state.cameraDrop ? 'camera-drop absolute inset-0' : 'absolute inset-0'}
        onClick={() => {
          if (state.phase === 'paused' && !state.lockUnavailable) begin()
        }}
      />
      <Hud />

      {state.phase === 'title' && <TitleScreen ready={ready} error={error} onBegin={begin} />}

      {state.phase === 'paused' && (
        <button
          type="button"
          onClick={begin}
          className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 font-mono text-[#d9d4c7]"
        >
          <span className="font-serif text-4xl tracking-[0.2em]">PAUSED</span>
          <span className="mt-4 text-xs uppercase tracking-[0.35em] text-[#d9d4c7]/60">
            {state.lockUnavailable ? 'Press Esc or click to return' : 'Click to return to the station'}
          </span>
        </button>
      )}

      {state.phase === 'ended' && <EndCard />}
    </main>
  )
}

function TitleScreen({ ready, error, onBegin }: { ready: boolean; error: string | null; onBegin: () => void }) {
  return (
    <section className="absolute inset-0 flex flex-col items-center justify-center bg-black px-6 text-center text-[#d9d4c7]">
      <div aria-hidden className="grain pointer-events-none absolute inset-[-50%] opacity-[0.07]" />
      <p className="mb-6 font-mono text-[10px] uppercase tracking-[0.5em] text-[#d9d4c7]/45">Purulia district · 02:14 AM</p>
      <h1 className="font-serif text-5xl font-light tracking-[0.18em] md:text-7xl">BEGUNKODOR</h1>
      <p className="mt-3 font-serif text-lg italic tracking-[0.3em] text-[#d9d4c7]/70 md:text-xl">The Last Train</p>

      <div className="mt-12 max-w-md space-y-2 font-mono text-[11px] uppercase leading-relaxed tracking-[0.25em] text-[#d9d4c7]/55">
        <p>Use headphones. Play in the dark.</p>
        <p>WASD move · Mouse look · Shift run</p>
        <p>F torch · C phone camera · E interact</p>
      </div>

      {error ? (
        <p className="mt-12 font-mono text-xs uppercase tracking-[0.25em] text-[#b3261e]">{error}</p>
      ) : (
        <button
          type="button"
          onClick={onBegin}
          disabled={!ready}
          className="mt-12 border border-[#d9d4c7]/30 px-8 py-3 font-mono text-xs uppercase tracking-[0.4em] text-[#d9d4c7] transition-colors hover:border-[#d9d4c7]/80 hover:bg-[#d9d4c7]/5 disabled:opacity-40"
        >
          {ready ? 'Enter the station' : 'Loading…'}
        </button>
      )}

      <p className="absolute bottom-6 max-w-lg px-6 font-mono text-[10px] leading-relaxed tracking-[0.2em] text-[#d9d4c7]/35">
        Contains psychological horror, sudden sounds and flashing lights. Desktop with keyboard and mouse required.
      </p>
    </section>
  )
}

function EndCard() {
  return (
    <section className="end-in absolute inset-0 flex flex-col items-center justify-center bg-black px-6 text-center text-[#d9d4c7]">
      <p className="max-w-2xl font-serif text-2xl leading-relaxed tracking-wide md:text-4xl">
        The player did not enter the haunted station.
      </p>
      <p className="end-in-late mt-6 max-w-2xl font-serif text-2xl italic leading-relaxed tracking-wide text-[#b3261e] md:text-4xl">
        The haunted station entered the player&apos;s world.
      </p>
      <button
        type="button"
        onClick={() => window.location.reload()}
        className="end-in-late mt-16 border border-[#d9d4c7]/25 px-8 py-3 font-mono text-xs uppercase tracking-[0.4em] transition-colors hover:border-[#d9d4c7]/70"
      >
        Board again
      </button>
    </section>
  )
}
