import * as THREE from 'three'

function canvas(w: number, h: number) {
  const c = document.createElement('canvas')
  c.width = w
  c.height = h
  const ctx = c.getContext('2d')!
  return { c, ctx }
}

function speckle(ctx: CanvasRenderingContext2D, w: number, h: number, count: number, alpha: number, dark = true) {
  for (let i = 0; i < count; i++) {
    const v = dark ? Math.floor(Math.random() * 60) : 150 + Math.floor(Math.random() * 100)
    ctx.fillStyle = `rgba(${v},${v},${v},${Math.random() * alpha})`
    const s = Math.random() * 3 + 0.5
    ctx.fillRect(Math.random() * w, Math.random() * h, s, s)
  }
}

function stains(ctx: CanvasRenderingContext2D, w: number, h: number, count: number, color: string) {
  for (let i = 0; i < count; i++) {
    const x = Math.random() * w
    const y = Math.random() * h
    const r = 20 + Math.random() * 90
    const g = ctx.createRadialGradient(x, y, 0, x, y, r)
    g.addColorStop(0, color)
    g.addColorStop(1, 'rgba(0,0,0,0)')
    ctx.fillStyle = g
    ctx.fillRect(x - r, y - r, r * 2, r * 2)
  }
}

function toTex(c: HTMLCanvasElement, repeat = true) {
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  if (repeat) {
    t.wrapS = THREE.RepeatWrapping
    t.wrapT = THREE.RepeatWrapping
  }
  t.anisotropy = 4
  return t
}

export function concreteTexture() {
  const { c, ctx } = canvas(512, 512)
  ctx.fillStyle = '#5b5a57'
  ctx.fillRect(0, 0, 512, 512)
  speckle(ctx, 512, 512, 9000, 0.35)
  speckle(ctx, 512, 512, 3000, 0.15, false)
  stains(ctx, 512, 512, 18, 'rgba(20,22,20,0.35)')
  ctx.strokeStyle = 'rgba(25,25,25,0.6)'
  ctx.lineWidth = 2
  for (let i = 0; i <= 2; i++) {
    ctx.beginPath()
    ctx.moveTo(0, i * 256)
    ctx.lineTo(512, i * 256)
    ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(i * 256, 0)
    ctx.lineTo(i * 256, 512)
    ctx.stroke()
  }
  return toTex(c)
}

export function wallTexture() {
  const { c, ctx } = canvas(512, 512)
  ctx.fillStyle = '#b9b08f'
  ctx.fillRect(0, 0, 512, 512)
  ctx.fillStyle = '#2f4a3a'
  ctx.fillRect(0, 340, 512, 172)
  ctx.fillStyle = '#1e2f25'
  ctx.fillRect(0, 334, 512, 8)
  speckle(ctx, 512, 512, 6000, 0.25)
  stains(ctx, 512, 512, 14, 'rgba(60,50,30,0.35)')
  for (let i = 0; i < 26; i++) {
    const x = Math.random() * 512
    const g = ctx.createLinearGradient(x, 0, x, 300)
    g.addColorStop(0, 'rgba(40,35,20,0.5)')
    g.addColorStop(1, 'rgba(40,35,20,0)')
    ctx.fillStyle = g
    ctx.fillRect(x, 0, 2 + Math.random() * 6, 200 + Math.random() * 200)
  }
  return toTex(c)
}

export function tileTexture() {
  const { c, ctx } = canvas(512, 512)
  for (let y = 0; y < 8; y++)
    for (let x = 0; x < 8; x++) {
      const v = (x + y) % 2 === 0 ? 150 : 60
      ctx.fillStyle = `rgb(${v},${v - 6},${v - 12})`
      ctx.fillRect(x * 64, y * 64, 64, 64)
    }
  speckle(ctx, 512, 512, 5000, 0.3)
  stains(ctx, 512, 512, 10, 'rgba(30,25,15,0.4)')
  return toTex(c)
}

export function gravelTexture() {
  const { c, ctx } = canvas(512, 512)
  ctx.fillStyle = '#3b3833'
  ctx.fillRect(0, 0, 512, 512)
  for (let i = 0; i < 14000; i++) {
    const v = 30 + Math.floor(Math.random() * 70)
    ctx.fillStyle = `rgb(${v},${v - 4},${v - 8})`
    const s = 1 + Math.random() * 4
    ctx.beginPath()
    ctx.arc(Math.random() * 512, Math.random() * 512, s, 0, Math.PI * 2)
    ctx.fill()
  }
  return toTex(c)
}

export function edgeTexture() {
  const { c, ctx } = canvas(256, 64)
  ctx.fillStyle = '#a8902e'
  ctx.fillRect(0, 0, 256, 64)
  speckle(ctx, 256, 64, 1500, 0.4)
  return toTex(c)
}

export function signTexture(lines: string[], bg = '#d9b52b', fg = '#111') {
  const { c, ctx } = canvas(1024, 256)
  ctx.fillStyle = bg
  ctx.fillRect(0, 0, 1024, 256)
  ctx.strokeStyle = fg
  ctx.lineWidth = 10
  ctx.strokeRect(12, 12, 1000, 232)
  ctx.fillStyle = fg
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  const h = 220 / lines.length
  lines.forEach((l, i) => {
    ctx.font = `bold ${Math.floor(h * 0.62)}px sans-serif`
    ctx.fillText(l, 512, 18 + h * (i + 0.5))
  })
  speckle(ctx, 1024, 256, 2500, 0.35)
  stains(ctx, 1024, 256, 6, 'rgba(50,30,10,0.35)')
  return toTex(c, false)
}

export function paperTexture(title: string, lines: string[]) {
  const { c, ctx } = canvas(512, 512)
  ctx.fillStyle = '#d8d0b8'
  ctx.fillRect(0, 0, 512, 512)
  stains(ctx, 512, 512, 8, 'rgba(120,90,40,0.25)')
  ctx.fillStyle = '#2a2418'
  ctx.font = 'bold 34px serif'
  ctx.fillText(title, 30, 60)
  ctx.font = '22px serif'
  lines.forEach((l, i) => ctx.fillText(l, 30, 110 + i * 32))
  return toTex(c, false)
}

export function clockCanvas() {
  const { c, ctx } = canvas(256, 256)
  const tex = toTex(c, false)
  const draw = (h: number, m: number) => {
    ctx.clearRect(0, 0, 256, 256)
    ctx.fillStyle = '#e8e2cf'
    ctx.beginPath()
    ctx.arc(128, 128, 120, 0, Math.PI * 2)
    ctx.fill()
    ctx.lineWidth = 10
    ctx.strokeStyle = '#1b1b1b'
    ctx.stroke()
    ctx.fillStyle = '#1b1b1b'
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2
      ctx.fillRect(128 + Math.sin(a) * 100 - 3, 128 - Math.cos(a) * 100 - 8, 6, 16)
    }
    const hand = (angle: number, len: number, w: number) => {
      ctx.save()
      ctx.translate(128, 128)
      ctx.rotate(angle)
      ctx.fillRect(-w / 2, -len, w, len + 12)
      ctx.restore()
    }
    hand(((h % 12) + m / 60) * (Math.PI / 6), 60, 9)
    hand(m * (Math.PI / 30), 92, 6)
    speckle(ctx, 256, 256, 600, 0.3)
    tex.needsUpdate = true
  }
  return { tex, draw }
}

export function silhouetteTexture() {
  const { c, ctx } = canvas(256, 512)
  ctx.filter = 'blur(6px)'
  ctx.fillStyle = 'rgba(0,0,0,0.92)'
  ctx.beginPath()
  ctx.ellipse(128, 70, 34, 42, 0, 0, Math.PI * 2)
  ctx.fill()
  ctx.beginPath()
  ctx.moveTo(90, 80)
  ctx.quadraticCurveTo(70, 200, 80, 260)
  ctx.lineTo(176, 260)
  ctx.quadraticCurveTo(186, 200, 166, 80)
  ctx.fill()
  ctx.beginPath()
  ctx.moveTo(84, 130)
  ctx.lineTo(60, 500)
  ctx.lineTo(196, 500)
  ctx.lineTo(172, 130)
  ctx.fill()
  ctx.fillRect(56, 140, 14, 170)
  ctx.fillRect(186, 140, 14, 170)
  const t = new THREE.CanvasTexture(c)
  return t
}

export function radialAlpha() {
  const { c, ctx } = canvas(128, 128)
  const g = ctx.createRadialGradient(64, 60, 10, 64, 64, 64)
  g.addColorStop(0, '#fff')
  g.addColorStop(0.6, '#ddd')
  g.addColorStop(1, '#000')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, 128, 128)
  return new THREE.CanvasTexture(c)
}

export function paleFaceTexture() {
  const { c, ctx } = canvas(128, 160)
  ctx.filter = 'blur(3px)'
  ctx.fillStyle = '#cfcfc8'
  ctx.beginPath()
  ctx.ellipse(64, 80, 40, 56, 0, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = '#0a0a0a'
  ctx.beginPath()
  ctx.ellipse(46, 70, 9, 6, 0, 0, Math.PI * 2)
  ctx.ellipse(82, 70, 9, 6, 0, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = 'rgba(30,20,20,0.6)'
  ctx.fillRect(52, 112, 24, 3)
  return new THREE.CanvasTexture(c)
}

export function textLabel(text: string, w = 512, h = 128, color = '#ddd', font = 'bold 48px monospace', bg = 'rgba(0,0,0,0)') {
  const { c, ctx } = canvas(w, h)
  const tex = toTex(c, false)
  const draw = (t: string) => {
    ctx.clearRect(0, 0, w, h)
    ctx.fillStyle = bg
    ctx.fillRect(0, 0, w, h)
    ctx.fillStyle = color
    ctx.font = font
    ctx.textBaseline = 'middle'
    ctx.fillText(t, 16, h / 2)
    tex.needsUpdate = true
  }
  draw(text)
  return { tex, draw }
}
