export type Subtitle = { speaker?: string; text: string; translation?: string; whisper?: boolean }

export type HudState = {
  phase: 'title' | 'loading' | 'playing' | 'paused' | 'ended'
  objective: string
  objectiveKey: number
  subtitle: Subtitle | null
  prompt: string | null
  cameraMode: boolean
  selfie: boolean
  cameraDrop: boolean
  phone: null | { state: 'ringing' | 'active' | 'ended'; caller: string }
  notification: string | null
  photo: string | null
  photoCaption: string
  fade: number
  fadeMs: number
  fear: number
  hand: boolean
  flashlight: boolean
  clock: string
  note: { title: string; body: string } | null
  hint: string | null
  lockUnavailable: boolean
}

const initial: HudState = {
  phase: 'title',
  objective: '',
  objectiveKey: 0,
  subtitle: null,
  prompt: null,
  cameraMode: false,
  selfie: false,
  cameraDrop: false,
  phone: null,
  notification: null,
  photo: null,
  photoCaption: '',
  fade: 1,
  fadeMs: 0,
  fear: 0,
  hand: false,
  flashlight: true,
  clock: '2:14',
  note: null,
  hint: null,
  lockUnavailable: false,
}

type Listener = () => void

class HudStore {
  private state: HudState = { ...initial }
  private listeners = new Set<Listener>()

  getState = () => this.state

  subscribe = (l: Listener) => {
    this.listeners.add(l)
    return () => {
      this.listeners.delete(l)
    }
  }

  set(partial: Partial<HudState>) {
    let changed = false
    for (const key in partial) {
      const k = key as keyof HudState
      if (this.state[k] !== partial[k]) {
        changed = true
        break
      }
    }
    if (!changed) return
    this.state = { ...this.state, ...partial }
    this.listeners.forEach((l) => l())
  }

  reset() {
    this.state = { ...initial }
    this.listeners.forEach((l) => l())
  }
}

export const hud = new HudStore()
