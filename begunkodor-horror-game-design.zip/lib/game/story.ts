import * as THREE from 'three'
import type { Game } from './game'
import { hud } from './hud-store'
import { animateAvatar } from './entities'

type Hook = (dt: number) => void

const fmtDate = (d: Date) =>
  `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`

export class Story {
  g: Game
  cutscene = false
  hooks = new Set<Hook>()
  hasOfficeKey = false
  hasGateKey = false
  private movingTime = 0
  private cameraStage = 0
  private lastCameraOpen = -99

  constructor(g: Game) {
    this.g = g
  }

  update(dt: number) {
    if (this.g.player.speed > 0.6) this.movingTime += dt
    this.hooks.forEach((h) => h(dt))
  }

  tween(seconds: number, fn: (t: number) => void) {
    return new Promise<void>((resolve) => {
      let t = 0
      const hook: Hook = (dt) => {
        t += dt
        const k = Math.min(1, t / seconds)
        fn(k)
        if (k >= 1) {
          this.hooks.delete(hook)
          resolve()
        }
      }
      this.hooks.add(hook)
    })
  }

  arjun(text: string, translation?: string, seconds = 3.2) {
    this.g.say({ speaker: 'Arjun', text, translation }, seconds)
  }

  // ======================================================================
  async run() {
    const g = this.g
    g.setAmbient(1, 5)
    await g.fadeTo(0, 3.5)
    hud.set({ hint: 'WASD move · Mouse look · Shift run · F torch · C phone camera · E interact' })
    g.wait(10).then(() => hud.set({ hint: null }))
    await g.wait(1.5)
    this.arjun('Aakhri train chhoot gayi...', 'Missed the last train...')
    await g.wait(3.6)
    this.arjun('Aur bahar ka gate bhi band hai.', 'And the exit gate is locked.')
    g.setObjective("The exit gate is locked. Find the Station Master's office.")
    const gate = g.addInteractable({
      id: 'exitGate',
      pos: g.world.doors.exit.center,
      radius: 2.4,
      prompt: '[E] Try the gate',
      onUse: () => {
        g.audio.knock(g.world.doors.exit.center, 0.5)
        this.arjun(this.hasGateKey ? 'Chaabi... lag nahi rahi.' : 'Band hai. Taala laga hai.', this.hasGateKey ? "The key... won't turn." : "It's locked. Padlocked.")
        g.wait(2).then(() => {
          if (!this.cutscene) gate.enabled = true
        })
      },
    })

    await this.platformFootsteps()
    g.fear.enabled = true

    await g.waitUntil(() => g.region === 'office' && g.player.pos.x < -5.4)
    await this.officeEvent()
    this.mirrorEvent()

    await g.waitUntil(() => g.region === 'platform')
    await g.wait(5)
    await this.phoneCall()
    g.setObjective('Open the CCTV room.')
    this.enableCameraTrick()
    this.enableCctvDoor()

    await g.waitUntil(() => g.player.pos.z < -7 || g.region === 'cctv', 70)
    await this.nameAnnouncement()

    await g.waitUntil(() => g.region === 'cctv' && g.player.pos.x < -9.2)
    await this.cctvEvent()

    await g.waitUntil(() => g.region === 'platform')
    await this.runningEvent()
    await this.revealHiddenDoor()

    await g.waitUntil(() => g.region === 'copy')
    await this.copyRoom()

    await g.waitUntil(() => g.region === 'bridge' && g.player.pos.x > -0.6)
    await this.bridgeEvent()

    await g.waitUntil(() => g.region === 'platform' && g.player.pos.z > -45)
    await this.trainEvent()

    await g.waitUntil(() => g.region === 'hall' && g.player.pos.x < -7)
    await this.faceReveal()
    await this.morning()
  }

  // ---------- 6. The first extreme event ----------
  async platformFootsteps() {
    const g = this.g
    await g.waitUntil(() => this.movingTime > 9 && g.region === 'platform')
    g.setAmbient(0, 2.5)
    await g.wait(2)
    let dist = 9
    let turns = 0
    let looking = false
    let steps = 0
    let source = g.behindPoint(dist)
    const listener = () => {
      if (looking) return
      g.wait(0.17).then(() => {
        if (looking) return
        const v = g.player.vel
        const len = Math.hypot(v.x, v.z) || 1
        source = new THREE.Vector3(g.player.pos.x - (v.x / len) * dist, 0, g.player.pos.z - (v.z / len) * dist)
        g.audio.footstep({ x: source.x, y: 0.1, z: source.z }, 0.5)
        steps++
        if (turns === 0 && steps > 22) dist = Math.max(2, dist - 0.3)
      })
    }
    g.stepListeners.push(listener)
    await g.waitUntil(() => {
      const facing = g.flatAngleTo(source) < 1.0
      if (facing && !looking) {
        looking = true
        turns++
        dist = turns === 1 ? 4.5 : 2.2
      } else if (!facing && looking && g.player.speed > 0.5) {
        looking = false
      }
      return turns >= 2 || steps > 40
    }, 120)
    await g.wait(turns >= 2 ? 1.5 : 0.4)
    g.stepListeners = g.stepListeners.filter((l) => l !== listener)
    await g.wait(1.2)
    await g.announce('Peeche mat dekho.', "Don't look back.")
    g.fear.bump(0.35)
    g.setAmbient(1, 7)
  }

  // ---------- 4. Fake safety ----------
  async officeEvent() {
    const g = this.g
    const w = g.world
    this.cutscene = true
    g.fear.enabled = false
    await g.wait(0.6)
    w.closeDoor('office', 4.5)
    await g.wait(0.3)
    g.audio.slam(w.doors.office.center, 0.9)
    g.shake(0.4)
    w.doors.office.locked = true
    g.setAmbient(0, 0.2)
    await g.wait(4.5)
    // breathing — inside the room
    const breathPos = { x: -6.2, y: 1.5, z: -5.2 }
    const secs = g.audio.breath(breathPos, 4, 0.5) ?? 10
    await g.wait(secs + 2)
    // the drawer opens by itself
    g.audio.creak({ x: -11.2, y: 0.7, z: -0.5 }, 3.2, 0.3)
    await this.tween(3.2, (t) => {
      w.drawer.position.x = -11.3 + t * 0.38
    })
    w.lamps.office.flicker = 0.4
    g.fear.bump(0.25)
    this.cutscene = false

    let taken = false
    const keyPos = new THREE.Vector3()
    w.officeKey.getWorldPosition(keyPos)
    g.addInteractable({
      id: 'officeKey',
      pos: keyPos,
      radius: 2.2,
      prompt: '[E] Take the key',
      onUse: () => {
        taken = true
      },
    })
    await g.waitUntil(() => taken)
    w.officeKey.visible = false
    this.hasOfficeKey = true
    g.audio.click(null, 0.2)
    this.arjun('"CCTV ROOM" likha hai.', 'It says "CCTV ROOM".')
    await g.showNote(
      'Note in the drawer',
      'Agar koi ladka 2:14 pe aaye, toh usse CCTV dikha dena.\nWoh phir bhool jayega.\n\n(If a boy comes at 2:14, show him the CCTV.\nHe will forget again.)\n\n— S.M.',
    )
    // she is standing by the door, waiting for him to turn
    const spot = new THREE.Vector3(-4.9, 0, 3.0)
    g.showGirl(g.girl, spot, { mode: 'static' })
    const seen = await g.waitUntil(() => g.angleTo(new THREE.Vector3(spot.x, 1.4, spot.z)) < 0.45, 30)
    if (seen) await g.wait(0.5)
    await g.blink(160)
    g.hideGirl(g.girl)
    await g.wait(1.5)
    g.audio.creak(w.doors.office.center, 2.8, 0.22)
    w.openDoor('office', 0.5, 0.8)
    g.setAmbient(1, 6)
    g.fear.enabled = true
  }

  // ---------- 7. The reflection ----------
  async mirrorEvent() {
    const g = this.g
    const w = g.world
    const mirrorPos = w.mirror.position
    await g.waitUntil(() => g.region === 'office' && g.distTo(mirrorPos) < 4.5 && g.angleTo(mirrorPos) < 0.35)
    const anchorX = g.player.pos.x
    g.avatarOverride = true
    const a = g.avatar
    let phase = 0
    let mode: 'wrong' | 'walk' | 'gone' = 'wrong'
    let lateral = 0
    const hook: Hook = (dt) => {
      if (mode === 'wrong') {
        a.position.set(2 * anchorX - g.player.pos.x, g.player.pos.y, g.player.pos.z)
        a.rotation.y = g.player.yaw + Math.PI
        phase += g.player.speed * dt * 4
        animateAvatar(a, phase, Math.min(1, g.player.speed / 2))
        lateral = Math.abs(g.player.pos.x - anchorX)
      } else if (mode === 'walk') {
        a.rotation.y = Math.PI / 2
        a.position.x += dt * 1.1
        phase += dt * 4.4
        animateAvatar(a, phase, 1)
      }
    }
    this.hooks.add(hook)
    await g.waitUntil(() => lateral > 0.9 || g.region !== 'office', 12)
    await g.waitUntil(() => g.player.speed < 0.2, 6)
    mode = 'walk'
    await g.wait(3.2)
    mode = 'gone'
    a.visible = false
    await g.waitUntil(() => g.flatAngleTo(mirrorPos) > 1.9 || g.region !== 'office', 10)
    // she stands behind him — only in the reflection
    const away = new THREE.Vector3(0, 0, -0.75)
    g.showGirl(g.girlReflect, g.player.pos.clone().add(away), { mode: 'static' })
    const back = await g.waitUntil(() => g.region === 'office' && g.angleTo(mirrorPos) < 0.3, 25)
    if (back) {
      g.girlReflect.position.copy(g.player.pos).add(away)
      await g.wait(2.4)
      g.fear.bump(0.35)
    }
    w.lamps.office.flicker = 0.5
    g.audio.flicker(w.lamps.office.light.position)
    await g.wait(0.25)
    g.hideGirl(g.girlReflect)
    this.hooks.delete(hook)
    a.visible = true
    g.avatarOverride = false
  }

  // ---------- 10. The phone call ----------
  async phoneCall() {
    const g = this.g
    const stopRing = g.audio.ring()
    hud.set({ phone: { state: 'ringing', caller: 'UNKNOWN' } })
    let answered = false
    g.globalAction = { prompt: '[E] Answer', fn: () => (answered = true) }
    await g.waitUntil(() => answered, 24)
    g.globalAction = null
    stopRing()
    hud.set({ phone: { state: 'active', caller: 'UNKNOWN' } })
    g.setAmbient(0.15, 0.6)
    await g.wait(3)
    this.arjun('Hello?')
    g.audio.speak('Hello?', { pitch: 1, rate: 0.9, volume: 0.7 })
    await g.wait(4)
    this.arjun('Hello? Kaun hai?', 'Hello? Who is this?')
    g.audio.speak('Hello? Kaun hai?', { pitch: 1, rate: 0.9, volume: 0.7 })
    await g.wait(4)
    g.audio.staticBurst(1, 0.08)
    await g.wait(1)
    g.say({ speaker: 'Phone — your own voice', text: 'Arjun... mat mudna.', translation: "Arjun... don't turn around." }, 4.5)
    await Promise.race([g.audio.speak('Arjun... mat mudna.', { pitch: 0.85, rate: 0.6, volume: 0.8 }), g.wait(5)])
    hud.set({ phone: { state: 'ended', caller: 'UNKNOWN' } })
    g.audio.click(null, 0.2)
    await g.wait(0.6)
    hud.set({ phone: null })
    g.fear.bump(0.3)
    await g.behind.footsteps(6, 7, 2.2, 0.6, 0.6)
    g.setAmbient(1, 6)
  }

  // ---------- 9. The camera trick ----------
  enableCameraTrick() {
    const g = this.g
    hud.set({ hint: 'Press C to raise your phone camera' })
    g.wait(7).then(() => hud.set({ hint: null }))
    g.onCameraToggle = (open) => {
      if (!open) {
        g.hideGirl(g.girlCam)
        return
      }
      if (this.cameraStage >= 4 || this.cutscene) return
      if (g.time - this.lastCameraOpen < 2.5) return
      this.lastCameraOpen = g.time
      if (this.cameraStage === 3) {
        this.cameraStage = 4
        this.selfieDrop()
        return
      }
      const want = [16, 9, 3.6][this.cameraStage]
      const f = g.flatForward(new THREE.Vector3())
      const free = g.world.freeDistance(g.player.pos.x, g.player.pos.z, g.player.pos.y, f.x, f.z, want + 1)
      const d = Math.min(want, free - 0.4)
      if (d < 1.8) return
      g.showGirl(g.girlCam, g.aheadPoint(d), { mode: 'static' })
      this.cameraStage++
    }
  }

  async selfieDrop() {
    const g = this.g
    g.selfie = true
    hud.set({ selfie: true })
    g.showGirl(g.girlCam, g.behindPoint(0.42, 0.18), { mode: 'static' })
    const hook: Hook = () => {
      g.girlCam.position.copy(g.behindPoint(0.42, 0.18))
      g.faceGirl(g.girlCam, g.aheadPoint(3))
    }
    this.hooks.add(hook)
    await g.wait(1.6)
    g.audio.sting(0.75)
    g.shake(1.2)
    hud.set({ cameraDrop: true })
    await g.wait(0.45)
    hud.set({ fade: 1, fadeMs: 60 })
    this.hooks.delete(hook)
    g.hideGirl(g.girlCam)
    g.selfie = false
    hud.set({ cameraDrop: false })
    g.toggleCamera(false)
    g.fear.bump(0.6)
    g.lookBehindSinceScare = 0
    await g.wait(2.2)
    hud.set({ fade: 0, fadeMs: 1500 })
  }

  enableCctvDoor() {
    const g = this.g
    const door = g.world.doors.cctv
    g.addInteractable({
      id: 'cctvDoor',
      pos: door.center,
      radius: 2.4,
      prompt: '[E] Unlock CCTV room',
      onUse: () => {
        g.audio.click(door.center, 0.5)
        g.world.openDoor('cctv', 1.1)
        g.audio.creak(door.center, 1.6, 0.2)
      },
    })
  }

  // ---------- 11. The name event ----------
  async nameAnnouncement() {
    const g = this.g
    await g.wait(this.g.audio.chime())
    g.audio.staticBurst(0.4, 0.12)
    g.say({ speaker: 'Station announcement', text: 'Arjun...' }, 3)
    await Promise.race([g.audio.speak('Arjun...', { pitch: 0.5, rate: 0.6 }), g.wait(3)])
    await g.wait(0.8)
    g.audio.staticBurst(1.6, 0.14)
    await g.wait(1.8)
    g.say({ speaker: 'Station announcement', text: 'Arjun, platform se door rahiye.', translation: 'Arjun, stay away from the platform.' }, 5)
    await Promise.race([g.audio.speak('Arjun, platform se door rahiye.', { pitch: 0.5, rate: 0.68 }), g.wait(5)])
    g.fear.bump(0.25)
    await g.wait(2)
    this.arjun('Isse... mera naam kaise pata?', 'How does it... know my name?')
  }

  // ---------- 22. The CCTV ----------
  async cctvEvent() {
    const g = this.g
    const w = g.world
    this.cutscene = true
    g.fear.enabled = false
    g.lockMove = true
    g.cctv.active = true
    g.cctv.which = 'platform'
    g.cctv.power = 1
    g.cctvCam.position.copy(w.cctvCamMesh.position)
    g.cctvCam.lookAt(-1.5, 1, 15)
    const monitor = w.cctvScreen.position
    g.forceLook(monitor, 4)
    g.setAmbient(0.25, 1)
    await g.wait(1.2)

    const past = g.pastAvatar
    past.visible = true
    past.position.set(-6, 0, 18)
    let sec = 4
    const stamp = (cam: string, m: number) => w.cctvStamp.draw(`${cam}  02:${m}:${String(sec).padStart(2, '0')}`)
    const clockHook: Hook = (dt) => {
      sec += dt
      if (sec >= 60) sec = 0
      stamp(g.cctv.which === 'platform' ? 'CAM 02' : 'CAM 04 LIVE', g.cctv.which === 'platform' && sec < 40 ? 16 : 17)
    }
    this.hooks.add(clockHook)

    // Arjun enters, walks toward the platform
    let phase = 0
    const from = new THREE.Vector3(-6, 0, 18)
    const to = new THREE.Vector3(0, 0, 13)
    past.rotation.y = Math.atan2(to.x - from.x, to.z - from.z)
    await this.tween(5.5, (t) => {
      past.position.lerpVectors(from, to, t)
      phase += 0.12
      animateAvatar(past, phase, 1)
    })
    animateAvatar(past, 0, 0)
    this.arjun('Yeh... main hoon.', "That's... me.")
    await g.wait(1.6)
    // he turns toward something off-camera
    const r0 = past.rotation.y
    await this.tween(1.2, (t) => {
      past.rotation.y = r0 + (Math.PI / 2 - r0) * t
    })
    await g.wait(1.4)
    g.showGirl(g.girlCctv, new THREE.Vector3(-0.9, 0, 13.3), { mode: 'static', facePlayer: false })
    g.girlCctv.rotation.y = Math.PI / 2
    g.audio.staticBurst(0.3, 0.06)
    await g.wait(3.5)
    g.releaseLook()
    this.arjun('Uske peeche...', 'Behind him...', 2.5)
    await g.wait(3)

    // 2:17 — she is beside the camera, looking straight into it
    sec = 41
    g.audio.staticBurst(0.6, 0.12)
    g.girlCctv.position.set(-3.2, 2.35, 7.0)
    g.faceGirl(g.girlCctv, w.cctvCamMesh.position)
    past.visible = false
    w.cctvMaterial.uniforms.noiseAmt.value = 0.35
    await g.wait(3.2)

    // the CCTV turns toward the player
    g.audio.staticBurst(1.2, 0.2)
    w.cctvMaterial.uniforms.noiseAmt.value = 0.6
    await g.wait(0.6)
    g.cctv.which = 'room'
    g.roomCam.position.set(-4.7, 3.1, -14.5)
    g.roomCam.lookAt(g.player.pos.x, 1.3, g.player.pos.z)
    w.cctvMaterial.uniforms.noiseAmt.value = 0.15
    const behindPos = () => {
      const toMonitor = new THREE.Vector3(monitor.x - g.player.pos.x, 0, monitor.z - g.player.pos.z).normalize()
      return g.player.pos.clone().sub(toMonitor.multiplyScalar(0.7))
    }
    g.girlCctv.position.copy(behindPos())
    g.faceGirl(g.girlCctv, g.player.pos)
    const roomHook: Hook = () => {
      g.girlCctv.position.copy(behindPos())
      g.faceGirl(g.girlCctv, g.player.pos)
    }
    this.hooks.add(roomHook)
    g.lockMove = false
    g.forceLook(monitor, 5)
    await g.wait(1.2)
    g.releaseLook()
    await g.waitUntil(() => g.flatAngleTo(monitor) > 1.9 || g.region !== 'cctv', 9)
    // turning around: nothing. the room dies.
    this.hooks.delete(roomHook)
    g.hideGirl(g.girlCctv)
    g.cctv.power = 0
    g.renderCctv()
    g.cctv.active = false
    w.setLamp('cctv', false)
    g.audio.click(w.lamps.cctv.light.position, 0.6)
    g.setAmbient(0, 0.1)
    await g.wait(2.5)
    w.setLamp('cctv', true)
    w.lamps.cctv.flicker = 0.6
    this.hooks.delete(clockHook)
    g.fear.bump(0.4)
    this.cutscene = false
    g.setAmbient(1, 5)
    g.setObjective('Get out of here.')
  }

  // ---------- 14. The running event ----------
  async runningEvent() {
    const g = this.g
    g.fear.enabled = false
    await g.waitUntil(() => g.player.speed > 0.5, 6)
    await g.wait(2)
    await g.behind.running()
    g.setAmbient(0, 0.05)
    g.shake(0.3)
    await g.wait(2.5)
    g.setObjective('SHE KNOWS YOU ARE HERE.')
    g.fear.bump(0.5)
    await g.wait(3)
    g.setAmbient(1, 6)
    g.fear.enabled = true
  }

  // ---------- 12. The room that should not exist ----------
  async revealHiddenDoor() {
    const g = this.g
    const w = g.world
    const doorPos = new THREE.Vector3(-4.15, 1.2, -40)
    // prepare the photograph: Arjun at the station, dated tomorrow
    this.preparePhotograph()
    await g.waitUntil(() => g.distTo(doorPos) < 34 && g.flatAngleTo(doorPos) > 1.5 && g.distTo(doorPos) > 6)
    w.hiddenPatch.mesh.visible = false
    w.hiddenPatch.collider.enabled = false
    w.doors.hidden.pivot.visible = true
    const lamp = w.lamps.copy
    lamp.on = true
    await g.waitUntil(() => g.angleTo(doorPos) < 0.5 && g.distTo(doorPos) < 20, 120)
    this.arjun('Yeh darwaza... pehle nahi tha.', "That door... wasn't there before.")
    g.setObjective("That door wasn't there before.")
  }

  preparePhotograph() {
    const g = this.g
    const w = g.world
    const rt = new THREE.WebGLRenderTarget(640, 460)
    const cam = new THREE.PerspectiveCamera(48, 640 / 460, 0.1, 80)
    cam.layers.enable(1)
    cam.position.set(0.8, 1.6, 20.5)
    cam.lookAt(0, 1.2, 25)
    const a = g.avatar
    const prevOverride = g.avatarOverride
    g.avatarOverride = true
    const prevPos = a.position.clone()
    const prevRot = a.rotation.y
    a.position.set(0, 0, 25)
    a.rotation.y = Math.PI * 0.95
    animateAvatar(a, 0, 0)
    const lampsOn = Object.values(w.lamps).map((l) => l.on)
    g.renderPhoto(rt, cam)
    Object.values(w.lamps).forEach((l, i) => (l.on = lampsOn[i]))
    a.position.copy(prevPos)
    a.rotation.y = prevRot
    g.avatarOverride = prevOverride
    ;(w.photoFrame.material as THREE.MeshBasicMaterial).dispose()
    w.photoFrame.material = new THREE.MeshBasicMaterial({ map: rt.texture, color: 0xd8c8a8 })
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    w.photoDate.draw(`${fmtDate(tomorrow)}  02:14`)
  }

  // ---------- 21. The loop ----------
  async copyRoom() {
    const g = this.g
    const w = g.world
    const today = fmtDate(new Date())
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    let found = 0
    const ticket = w.evidence.ticket
    ticket.position.set(-6.4, 0.012, -40.2)

    g.addInteractable({
      id: 'ticket',
      pos: ticket.position,
      radius: 2.2,
      prompt: '[E] Pick up the ticket',
      onUse: () => this.glancePickup(ticket, () => {
        found++
        g.showNote(
          'Unreserved ticket',
          `PURULIA → BEGUNKODOR\nJourney: ${today}   Dep. 01:52\nPassenger: ARJUN\n\nThe ticket has been punched seven times.\nEvery hole has the same date.`,
        )
      }),
    })
    g.addInteractable({
      id: 'diary',
      pos: w.evidence.diary.position,
      radius: 2.2,
      prompt: '[E] Read the diary',
      onUse: async () => {
        found++
        await g.showNote(
          "Station Master's diary",
          `${today}\nWoh ladka phir aaya. Arjun. 2:14 pe.\nPhir wahi sawaal. Phir wahi chehra.\nYeh saatvi baar hai. Woh kabhi yaad nahi rakhta.\n\n(The boy came again. Arjun. At 2:14.\nSame question. Same face.\nThis is the seventh time. He never remembers.)\n\nUs ladki ne kaha — "Is baar woh ghar jayega."\n(The girl said — "This time he goes home.")`,
        )
      },
    })
    g.addInteractable({
      id: 'recording',
      pos: w.evidence.recording.position,
      radius: 2.2,
      prompt: '[E] Play the voice recording',
      onUse: async () => {
        found++
        g.audio.staticBurst(1.2, 0.1)
        await g.wait(1.2)
        g.say(
          { speaker: 'Recording — your voice', text: 'Agar tum yeh sun rahe ho... toh tum phir se yahan ho. Woh hamesha peeche hoti hai.', translation: "If you're hearing this... you're here again. She is always behind you." },
          8,
        )
        await Promise.race([
          g.audio.speak('Agar tum yeh sun rahe ho... toh tum phir se yahan ho. Woh hamesha peeche hoti hai.', { pitch: 0.9, rate: 0.75 }),
          g.wait(9),
        ])
        g.audio.staticBurst(0.6, 0.1)
      },
    })
    g.addInteractable({
      id: 'photo',
      pos: w.photoFrame.position,
      radius: 2.6,
      prompt: '[E] Look at the photograph',
      onUse: async () => {
        found++
        this.arjun('Main... is platform pe. Aur taareekh... kal ki.', "Me... on this platform. And the date... tomorrow's.", 5)
        g.fear.bump(0.2)
      },
    })
    g.addInteractable({
      id: 'clock',
      pos: new THREE.Vector3(-6, 3.0, -34.2),
      radius: 4,
      prompt: '[E] Look at the clock',
      onUse: () => {
        found++
        this.arjun('Ghadi 2:14 pe ruki hui hai. Jaise pehle thi.', 'The clock stopped at 2:14. Just like before.', 4.5)
      },
    })

    await g.waitUntil(() => found >= 3, 150)
    await g.wait(4)
    const n = g.lookBehindCount
    if (n > 0) {
      const word = n === 1 ? 'ek' : String(n)
      await g.announce(`Arjun... aapne ${word} baar peeche mudke dekha hai.`, `Arjun... you have looked behind you ${n} time${n === 1 ? '' : 's'}.`)
    } else {
      await g.announce('Arjun... aapne ek baar bhi peeche nahi dekha. Achha kiya.', "Arjun... you haven't looked back even once. Good.")
    }
    g.fear.bump(0.3)
    await g.wait(1.5)
    this.arjun('Footbridge... doosri taraf koi raasta hoga.', "The footbridge... there must be a way out on the other side.", 4.5)
    g.setObjective('Cross the footbridge.')
  }

  /** 2. Look down at an item. Look back up. She is at the end of the room. */
  async glancePickup(item: THREE.Object3D, after: () => void) {
    const g = this.g
    this.cutscene = true
    g.lockMove = true
    const itemPos = new THREE.Vector3()
    item.getWorldPosition(itemPos)
    g.forceLook(itemPos, 6)
    await g.wait(1.1)
    item.visible = false
    g.audio.click(null, 0.15)
    const f = g.flatForward(new THREE.Vector3())
    const free = g.world.freeDistance(g.player.pos.x, g.player.pos.z, g.player.pos.y, f.x, f.z, 14)
    if (free > 4) g.showGirl(g.girl, g.aheadPoint(free - 0.6), { mode: 'static' })
    const ahead = g.player.pos.clone().add(f.multiplyScalar(6)).setY(1.5)
    g.forceLook(ahead, 2.5)
    await g.wait(1.3)
    g.releaseLook()
    if (g.girl.visible) {
      await g.wait(0.7)
      await g.blink(150)
      g.hideGirl(g.girl)
      g.fear.bump(0.3)
    }
    g.lockMove = false
    this.cutscene = false
    after()
  }

  // ---------- 15. The footbridge ----------
  async bridgeEvent() {
    const g = this.g
    const w = g.world
    this.cutscene = true
    g.fear.enabled = false
    g.setAmbient(0.35, 2)
    for (const k of ['b0', 'b1', 'b2']) {
      await g.waitUntil(() => g.player.pos.x > (k === 'b0' ? 0.5 : k === 'b1' ? 2.5 : 5), 20)
      await g.wait(0.6)
      w.setLamp(k, false)
      g.audio.click(w.lamps[k].light.position, 0.7)
      await g.wait(1.2)
    }
    // one light remains. under it, the girl — back facing the player.
    const spot = new THREE.Vector3(14, 5, -58)
    g.showGirl(g.girl, spot, { mode: 'static', facePlayer: false })
    g.girl.rotation.y = Math.PI / 2
    await g.waitUntil(() => g.player.pos.x > 9.8 || g.distTo(spot) < 4.5, 90)
    w.setLamp('b3', false)
    g.audio.click(w.lamps.b3.light.position, 0.7)
    const wasOn = g.flashOn
    g.flashOn = false
    g.flashlight.intensity = 0
    g.lockMove = true
    await g.wait(1.4)
    const front = g.aheadPoint(0.85)
    front.y = 5
    g.girl.position.copy(front)
    g.faceGirl(g.girl)
    w.setLamp('b3', true)
    g.flashOn = wasOn
    g.forceLook(new THREE.Vector3(front.x, front.y + 1.55, front.z), 7)
    await g.wait(3.2)
    g.releaseLook()
    await g.blink(160)
    g.hideGirl(g.girl)
    g.lockMove = false
    g.fear.bump(0.5)
    this.cutscene = false
    await g.wait(1.5)

    w.gateKey.visible = true
    let got = false
    g.addInteractable({
      id: 'gateKey',
      pos: w.gateKey.position,
      radius: 2.2,
      prompt: '[E] Pick up the keys',
      onUse: () => {
        got = true
      },
    })
    this.arjun('Wahan... kuch chamak raha hai.', 'Something is glinting over there.')
    await g.waitUntil(() => got)
    w.gateKey.visible = false
    this.hasGateKey = true
    g.audio.click(null, 0.25)
    this.arjun('Gate ki chaabi.', 'The gate keys.')
    g.setObjective('Go back down. Open the exit gate.')
    for (const k of ['b0', 'b1', 'b2']) {
      w.lamps[k].flicker = 0.5
      w.setLamp(k, true)
      await g.wait(0.4)
    }
    g.setAmbient(1, 4)
    g.fear.enabled = true
  }

  // ---------- 16. The train window ----------
  async trainEvent() {
    const g = this.g
    const t = g.train
    g.fear.enabled = false
    this.cutscene = true
    await g.wait(1.5)
    t.visible = true
    t.position.set(6.5, -0.6, 150)
    t.userData.girl.visible = true
    t.userData.headlight.intensity = 30
    const sound = g.audio.train()
    g.audio.horn({ x: 6.5, y: 2, z: 120 }, 2.4, 0.5)
    this.arjun('Train?! Is waqt?', 'A train?! At this hour?')
    const speed = 10
    const girlWorld = new THREE.Vector3()
    const hook: Hook = (dt) => {
      t.position.z -= speed * dt
      const front = t.position.z
      const back = t.position.z + t.userData.length
      const z = THREE.MathUtils.clamp(g.player.pos.z, front, back)
      if (sound?.panner.positionZ) {
        sound.panner.positionX.value = 6.5
        sound.panner.positionY.value = 1
        sound.panner.positionZ.value = z
      }
      const ng = t.userData.girl
      ng.getWorldPosition(girlWorld)
      ng.rotation.y = Math.atan2(g.player.pos.x - girlWorld.x, g.player.pos.z - girlWorld.z)
      if (Math.abs(girlWorld.z - g.player.pos.z) < 12) g.fear.fear = Math.min(1, g.fear.fear + dt * 0.05)
    }
    this.hooks.add(hook)
    await g.waitUntil(() => t.position.z + t.userData.length < g.player.pos.z - 25, 60)
    sound?.stop(2.5)
    this.hooks.delete(hook)
    await g.wait(2.5)
    t.visible = false
    t.userData.girl.visible = false
    t.userData.headlight.intensity = 0
    g.setAmbient(0, 1)
    this.cutscene = false
    await g.wait(2.5)
    // she is standing behind him
    let pos = g.behindPoint(2)
    if (!g.spotFree(pos)) pos = g.behindPoint(1.3)
    g.showGirl(g.girl, pos, { mode: 'vanishOnLook', lookAngle: 0.35, dwellNeeded: 0.8, blinkVanish: true, maxTime: 30 })
    await g.waitUntil(() => !g.girl.visible, 32)
    g.hideGirl(g.girl)
    g.fear.bump(0.4)
    g.setAmbient(1, 5)
    g.fear.enabled = true
  }

  // ---------- 20. The face ----------
  async faceReveal() {
    const g = this.g
    const w = g.world
    this.cutscene = true
    g.fear.enabled = false
    g.lockMove = true
    g.setAmbient(0, 1)
    w.lamps.hall.flicker = 0.8
    g.audio.flicker(w.lamps.hall.light.position)
    await g.wait(0.8)
    w.setLamp('hall', false)
    w.setLamp('street', false)
    g.setFlashBroken(1.4)
    if (!g.flashOn) g.toggleFlashlight(true)
    const exit = new THREE.Vector3(-16, 0, 18)
    const dir = exit.clone().sub(g.player.pos).setY(0).normalize()
    const spot = g.player.pos.clone().add(dir.multiplyScalar(1.9))
    g.girl.userData.setFace(true)
    g.showGirl(g.girl, spot, { mode: 'static' })
    g.forceLook(new THREE.Vector3(spot.x, 1.58, spot.z), 3)
    await g.wait(3.5)
    g.audio.whisper({ x: spot.x, y: 1.6, z: spot.z }, 2.4, 0.5)
    g.say({ speaker: 'Her', text: 'Tum mujhe pehle bhi dekh chuke ho.', translation: 'You have seen me before.', whisper: true }, 5)
    g.audio.speak('Tum mujhe pehle bhi dekh chuke ho.', { pitch: 1.3, rate: 0.6, volume: 0.45 })
    await g.wait(5.5)
    this.arjun('Kab?', 'When?', 2.5)
    g.audio.speak('Kab?', { pitch: 1, rate: 0.85, volume: 0.7 })
    await g.wait(3)
    g.audio.whisper({ x: spot.x, y: 1.6, z: spot.z }, 1, 0.55)
    g.say({ speaker: 'Her', text: 'Har baar.', translation: 'Every time.', whisper: true }, 3)
    g.audio.speak('Har baar.', { pitch: 1.3, rate: 0.55, volume: 0.45 })
    await g.wait(3.2)
    hud.set({ fade: 1, fadeMs: 0 })
    g.audio.slam(null, 0.6)
    g.hideGirl(g.girl)
    g.girl.userData.setFace(false)
    g.releaseLook()
  }

  // ---------- 23 & 24. Leaving ----------
  async morning() {
    const g = this.g
    const w = g.world
    await g.wait(3)
    // the environment resets — into morning
    for (const k in w.lamps) w.setLamp(k, false)
    w.rain.visible = false
    const fog = g.scene.fog as THREE.FogExp2
    fog.color.set(0x8f989c)
    fog.density = 0.028
    ;(g.scene.background as THREE.Color).set(0x8f989c)
    w.hemi.color.set(0xd4dce2)
    w.hemi.groundColor.set(0x504a40)
    w.hemi.intensity = 2.4
    const sun = new THREE.DirectionalLight(0xffe2c0, 1.4)
    sun.position.set(-40, 30, 10)
    g.scene.add(sun)
    g.toggleFlashlight(false)
    g.clockMinutes = 14
    g.clockFrozen = true
    w.clock.draw(6, 2)
    g.audio.setMorning()
    g.player.pos.set(-7, 0, 18)
    g.player.yaw = Math.PI / 2
    g.player.pitch = 0
    w.doors.exit.locked = false
    w.openDoor('exit', 1, 1)
    g.lockMove = false
    this.cutscene = true
    g.setAmbient(1, 3)
    await g.fadeTo(0, 3.5)
    g.setObjective('LEAVE.')
    await g.waitUntil(() => g.player.pos.x < -22)
    // the station disappears behind fog
    await this.tween(4, (t) => {
      fog.density = 0.028 + t * 0.09
    })
    g.audio.breath(null, 1, 0.35)
    await g.wait(1.2)
    this.arjun('Bas... ghar.', 'Just... home.')
    await g.wait(4.5)
    g.audio.ping()
    hud.set({ notification: '1 NEW PHOTO' })
    let opened = false
    g.globalAction = { prompt: '[E] Open photo', fn: () => (opened = true) }
    await g.waitUntil(() => opened, 20)
    g.globalAction = null
    hud.set({ notification: null })
    g.lockMove = true
    // photo taken from behind him
    const f = g.flatForward(new THREE.Vector3())
    const head = g.head()
    g.photoCam.position.set(head.x - f.x * 3.2, head.y + 0.1, head.z - f.z * 3.2)
    g.photoCam.lookAt(head.x, head.y - 0.35, head.z)
    const url = g.snapshot(g.photoCam)
    hud.set({ photo: url, photoCaption: 'Today · 06:02 AM' })
    await g.wait(5)
    hud.set({ photo: null })
    await g.wait(0.8)
    // the player slowly turns
    g.forceLook(g.photoCam.position, 0.9)
    await g.wait(2.3)
    hud.set({ fade: 1, fadeMs: 0 })
    g.audio.silenceWorld()
    await g.wait(1.6)
    g.audio.whisper(null, 1.4, 0.8, -1)
    g.say({ text: 'Ab ghar chalo.', translation: "Now... let's go home.", whisper: true }, 4)
    g.audio.speak('Ab ghar chalo.', { pitch: 1.3, rate: 0.55, volume: 0.4 })
    await g.wait(3.5)
    g.audio.horn(null, 3.2, 0.7)
    await g.wait(4)
    hud.set({ phase: 'ended' })
    if (document.pointerLockElement) document.exitPointerLock()
  }
}
