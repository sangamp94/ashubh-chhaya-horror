import type * as THREE from 'three'

type Vec = { x: number; y: number; z: number }

const rand = (a: number, b: number) => a + Math.random() * (b - a)

export class AudioEngine {
  ctx!: AudioContext
  private master!: GainNode
  private ambient!: GainNode
  private sfx!: GainNode
  private reverb!: ConvolverNode
  private reverbSend!: GainNode
  private rainFilter!: BiquadFilterNode
  private rainGain!: GainNode
  private insectGain!: GainNode
  private birdTimer: number | null = null
  private noise!: AudioBuffer
  private steps: AudioBuffer[] = []
  private heartbeatNext = 0
  ready = false

  init() {
    if (this.ready) return
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    this.ctx = new Ctx()
    const ctx = this.ctx

    const comp = ctx.createDynamicsCompressor()
    comp.threshold.value = -14
    comp.ratio.value = 4
    comp.connect(ctx.destination)

    this.master = ctx.createGain()
    this.master.gain.value = 0.9
    this.master.connect(comp)

    this.ambient = ctx.createGain()
    this.ambient.gain.value = 0
    this.ambient.connect(this.master)

    this.sfx = ctx.createGain()
    this.sfx.gain.value = 1
    this.sfx.connect(this.master)

    this.reverb = ctx.createConvolver()
    this.reverb.buffer = this.makeImpulse(3.2, 2.6)
    this.reverbSend = ctx.createGain()
    this.reverbSend.gain.value = 0.35
    this.reverbSend.connect(this.reverb)
    this.reverb.connect(this.master)

    this.noise = this.makeNoise(3)
    for (let i = 0; i < 8; i++) this.steps.push(this.makeStep())

    this.buildAmbience()
    this.ready = true
  }

  resume() {
    if (this.ctx?.state === 'suspended') this.ctx.resume()
  }

  suspend() {
    if (this.ctx?.state === 'running') this.ctx.suspend()
    if (typeof speechSynthesis !== 'undefined') speechSynthesis.pause()
  }

  unsuspend() {
    this.resume()
    if (typeof speechSynthesis !== 'undefined') speechSynthesis.resume()
  }

  get now() {
    return this.ctx.currentTime
  }

  private makeNoise(seconds: number, channels = 1) {
    const len = Math.floor(this.ctx.sampleRate * seconds)
    const buf = this.ctx.createBuffer(channels, len, this.ctx.sampleRate)
    for (let c = 0; c < channels; c++) {
      const d = buf.getChannelData(c)
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1
    }
    return buf
  }

  private makeImpulse(seconds: number, decay: number) {
    const rate = this.ctx.sampleRate
    const len = Math.floor(rate * seconds)
    const buf = this.ctx.createBuffer(2, len, rate)
    for (let c = 0; c < 2; c++) {
      const d = buf.getChannelData(c)
      for (let i = 0; i < len; i++) {
        const t = i / len
        d[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, decay) * (i < rate * 0.01 ? 0.3 : 1)
      }
    }
    return buf
  }

  private makeStep() {
    const rate = this.ctx.sampleRate
    const len = Math.floor(rate * 0.28)
    const buf = this.ctx.createBuffer(1, len, rate)
    const d = buf.getChannelData(0)
    let lp = 0
    let lp2 = 0
    const cutoff = rand(0.08, 0.16)
    const heel = rand(0.03, 0.06)
    for (let i = 0; i < len; i++) {
      const t = i / rate
      const n = Math.random() * 2 - 1
      lp += (n - lp) * cutoff
      lp2 += (lp - lp2) * 0.5
      const heelEnv = Math.exp(-t * 55)
      const toe = t > heel ? Math.exp(-(t - heel) * 70) * 0.7 : 0
      const thump = Math.sin(2 * Math.PI * 70 * t) * Math.exp(-t * 35) * 0.6
      const grit = (Math.random() * 2 - 1) * Math.exp(-t * 90) * 0.12
      d[i] = lp2 * 3.2 * (heelEnv + toe) + thump + grit
    }
    return buf
  }

  private buildAmbience() {
    const ctx = this.ctx
    // rain
    const rain = ctx.createBufferSource()
    rain.buffer = this.makeNoise(4, 2)
    rain.loop = true
    const hp = ctx.createBiquadFilter()
    hp.type = 'highpass'
    hp.frequency.value = 350
    this.rainFilter = ctx.createBiquadFilter()
    this.rainFilter.type = 'lowpass'
    this.rainFilter.frequency.value = 5200
    this.rainGain = ctx.createGain()
    this.rainGain.gain.value = 0.16
    rain.connect(hp).connect(this.rainFilter).connect(this.rainGain).connect(this.ambient)
    rain.start()

    // rain on tin roof — sparse droplets
    const dropLen = ctx.sampleRate * 3
    const dropBuf = ctx.createBuffer(2, dropLen, ctx.sampleRate)
    for (let c = 0; c < 2; c++) {
      const d = dropBuf.getChannelData(c)
      for (let k = 0; k < 260; k++) {
        const start = Math.floor(Math.random() * (dropLen - 2000))
        const amp = rand(0.05, 0.4)
        const f = rand(1800, 4200)
        for (let i = 0; i < 1600; i++) {
          d[start + i] += Math.sin((2 * Math.PI * f * i) / ctx.sampleRate) * Math.exp(-i / 180) * amp
        }
      }
    }
    const drops = ctx.createBufferSource()
    drops.buffer = dropBuf
    drops.loop = true
    const dropGain = ctx.createGain()
    dropGain.gain.value = 0.05
    drops.connect(this.rainFilter)
    drops.connect(dropGain).connect(this.ambient)
    drops.start()

    // wind
    const wind = ctx.createBufferSource()
    wind.buffer = this.noise
    wind.loop = true
    const bp = ctx.createBiquadFilter()
    bp.type = 'bandpass'
    bp.frequency.value = 320
    bp.Q.value = 0.9
    const lfo = ctx.createOscillator()
    lfo.frequency.value = 0.06
    const lfoGain = ctx.createGain()
    lfoGain.gain.value = 180
    lfo.connect(lfoGain).connect(bp.frequency)
    lfo.start()
    const windGain = ctx.createGain()
    windGain.gain.value = 0.09
    const lfo2 = ctx.createOscillator()
    lfo2.frequency.value = 0.11
    const lfo2Gain = ctx.createGain()
    lfo2Gain.gain.value = 0.05
    lfo2.connect(lfo2Gain).connect(windGain.gain)
    lfo2.start()
    wind.connect(bp).connect(windGain).connect(this.ambient)
    wind.start()

    // insects
    const iLen = ctx.sampleRate * 5
    const iBuf = ctx.createBuffer(2, iLen, ctx.sampleRate)
    for (let c = 0; c < 2; c++) {
      const d = iBuf.getChannelData(c)
      const f = c === 0 ? 4300 : 4700
      let t0 = Math.random() * 0.3
      while (t0 < 4.6) {
        const pulses = 3 + Math.floor(Math.random() * 3)
        for (let p = 0; p < pulses; p++) {
          const s = Math.floor((t0 + p * 0.045) * ctx.sampleRate)
          for (let i = 0; i < 0.03 * ctx.sampleRate && s + i < iLen; i++) {
            const env = Math.sin((Math.PI * i) / (0.03 * ctx.sampleRate))
            d[s + i] += Math.sin((2 * Math.PI * f * i) / ctx.sampleRate) * env * 0.5
          }
        }
        t0 += rand(0.35, 0.8)
      }
    }
    const insects = ctx.createBufferSource()
    insects.buffer = iBuf
    insects.loop = true
    this.insectGain = ctx.createGain()
    this.insectGain.gain.value = 0.025
    insects.connect(this.insectGain).connect(this.ambient)
    insects.start()

    // fluorescent hum
    const hum = ctx.createOscillator()
    hum.frequency.value = 100
    const hum2 = ctx.createOscillator()
    hum2.type = 'triangle'
    hum2.frequency.value = 50
    const humGain = ctx.createGain()
    humGain.gain.value = 0.006
    hum.connect(humGain)
    hum2.connect(humGain)
    humGain.connect(this.ambient)
    hum.start()
    hum2.start()
  }

  updateListener(camera: THREE.Camera, forward: Vec) {
    if (!this.ready) return
    const l = this.ctx.listener
    const p = camera.position
    if (l.positionX) {
      const t = this.ctx.currentTime
      l.positionX.setTargetAtTime(p.x, t, 0.02)
      l.positionY.setTargetAtTime(p.y, t, 0.02)
      l.positionZ.setTargetAtTime(p.z, t, 0.02)
      l.forwardX.setTargetAtTime(forward.x, t, 0.02)
      l.forwardY.setTargetAtTime(forward.y, t, 0.02)
      l.forwardZ.setTargetAtTime(forward.z, t, 0.02)
      l.upX.value = 0
      l.upY.value = 1
      l.upZ.value = 0
    } else {
      l.setPosition(p.x, p.y, p.z)
      l.setOrientation(forward.x, forward.y, forward.z, 0, 1, 0)
    }
  }

  setAmbient(level: number, seconds = 1.5) {
    if (!this.ready) return
    const g = this.ambient.gain
    g.cancelScheduledValues(this.now)
    g.setValueAtTime(g.value, this.now)
    g.linearRampToValueAtTime(level, this.now + Math.max(0.05, seconds))
  }

  setIndoor(indoor: boolean) {
    if (!this.ready) return
    this.rainFilter.frequency.setTargetAtTime(indoor ? 700 : 5200, this.now, 0.4)
    this.rainGain.gain.setTargetAtTime(indoor ? 0.1 : 0.16, this.now, 0.4)
    this.insectGain.gain.setTargetAtTime(indoor ? 0.004 : 0.025, this.now, 0.4)
    this.reverbSend.gain.setTargetAtTime(indoor ? 0.22 : 0.4, this.now, 0.4)
  }

  setMorning() {
    if (!this.ready) return
    this.rainGain.gain.setTargetAtTime(0, this.now, 1.5)
    this.insectGain.gain.setTargetAtTime(0.006, this.now, 2)
    this.startBirds()
  }

  private startBirds() {
    const chirp = () => {
      if (!this.ready) return
      const ctx = this.ctx
      const t = ctx.currentTime
      const n = 2 + Math.floor(Math.random() * 4)
      const pan = ctx.createStereoPanner()
      pan.pan.value = rand(-0.9, 0.9)
      pan.connect(this.ambient)
      for (let i = 0; i < n; i++) {
        const o = ctx.createOscillator()
        const g = ctx.createGain()
        const st = t + i * rand(0.08, 0.14)
        const f = rand(2400, 3600)
        o.frequency.setValueAtTime(f, st)
        o.frequency.exponentialRampToValueAtTime(f * rand(1.2, 1.6), st + 0.07)
        g.gain.setValueAtTime(0, st)
        g.gain.linearRampToValueAtTime(0.05, st + 0.01)
        g.gain.exponentialRampToValueAtTime(0.0001, st + 0.09)
        o.connect(g).connect(pan)
        o.start(st)
        o.stop(st + 0.1)
      }
      this.birdTimer = window.setTimeout(chirp, rand(600, 2600))
    }
    chirp()
  }

  silenceWorld() {
    if (this.birdTimer) clearTimeout(this.birdTimer)
    this.birdTimer = null
    this.setAmbient(0, 0.05)
  }

  stopAll() {
    if (this.birdTimer) clearTimeout(this.birdTimer)
    this.birdTimer = null
    if (typeof speechSynthesis !== 'undefined') speechSynthesis.cancel()
    if (this.ready) {
      this.setAmbient(0, 0.1)
      this.sfx.gain.setTargetAtTime(0, this.now, 0.05)
    }
  }

  // ---------- routing helpers ----------
  private out(pos: Vec | null, opts: { reverb?: number; pan?: number; refDistance?: number } = {}) {
    const ctx = this.ctx
    const g = ctx.createGain()
    if (pos) {
      const p = ctx.createPanner()
      p.panningModel = 'HRTF'
      p.distanceModel = 'inverse'
      p.refDistance = opts.refDistance ?? 1.2
      p.rolloffFactor = 1.1
      p.maxDistance = 80
      if (p.positionX) {
        p.positionX.value = pos.x
        p.positionY.value = pos.y
        p.positionZ.value = pos.z
      } else p.setPosition(pos.x, pos.y, pos.z)
      g.connect(p)
      p.connect(this.sfx)
      const send = ctx.createGain()
      send.gain.value = opts.reverb ?? 0.5
      p.connect(send).connect(this.reverbSend)
      return { input: g as AudioNode, panner: p as PannerNode | null }
    }
    const sp = ctx.createStereoPanner()
    sp.pan.value = opts.pan ?? 0
    g.connect(sp).connect(this.sfx)
    if (opts.reverb) {
      const send = ctx.createGain()
      send.gain.value = opts.reverb
      sp.connect(send).connect(this.reverbSend)
    }
    return { input: g as AudioNode, panner: null }
  }

  private noiseSource(loop = false) {
    const s = this.ctx.createBufferSource()
    s.buffer = this.noise
    s.loop = loop
    if (loop) s.loopStart = Math.random()
    return s
  }

  // ---------- sounds ----------
  footstep(pos: Vec | null, volume = 0.5, wet = true) {
    if (!this.ready) return
    const s = this.ctx.createBufferSource()
    s.buffer = this.steps[Math.floor(Math.random() * this.steps.length)]
    s.playbackRate.value = rand(0.88, 1.08)
    const g = this.ctx.createGain()
    g.gain.value = volume
    const o = this.out(pos, { reverb: pos ? 0.7 : 0.15 })
    s.connect(g).connect(o.input)
    if (wet) {
      const splash = this.noiseSource()
      const hp = this.ctx.createBiquadFilter()
      hp.type = 'highpass'
      hp.frequency.value = 3500
      const sg = this.ctx.createGain()
      const t = this.now
      sg.gain.setValueAtTime(volume * 0.18, t)
      sg.gain.exponentialRampToValueAtTime(0.0001, t + 0.12)
      splash.connect(hp).connect(sg).connect(o.input)
      splash.start(t, Math.random() * 2, 0.15)
    }
    s.start()
  }

  breath(pos: Vec | null, cycles = 3, volume = 0.5, pan = 0) {
    if (!this.ready) return
    const ctx = this.ctx
    const src = this.noiseSource(true)
    const bp = ctx.createBiquadFilter()
    bp.type = 'bandpass'
    bp.frequency.value = 1100
    bp.Q.value = 0.7
    const lp = ctx.createBiquadFilter()
    lp.type = 'lowpass'
    lp.frequency.value = 2400
    const g = ctx.createGain()
    g.gain.value = 0
    const o = this.out(pos, { reverb: 0.25, pan, refDistance: 0.8 })
    src.connect(bp).connect(lp).connect(g).connect(o.input)
    let t = this.now + 0.05
    for (let i = 0; i < cycles; i++) {
      const inhale = rand(0.9, 1.3)
      const exhale = rand(1.2, 1.7)
      g.gain.setValueAtTime(0, t)
      g.gain.linearRampToValueAtTime(volume * 0.7, t + inhale * 0.7)
      g.gain.linearRampToValueAtTime(0, t + inhale)
      bp.frequency.setValueAtTime(1500, t)
      bp.frequency.linearRampToValueAtTime(900, t + inhale + 0.3 + exhale)
      g.gain.setValueAtTime(0, t + inhale + 0.25)
      g.gain.linearRampToValueAtTime(volume, t + inhale + 0.4)
      g.gain.linearRampToValueAtTime(0, t + inhale + 0.25 + exhale)
      t += inhale + exhale + rand(0.4, 0.9)
    }
    src.start()
    src.stop(t + 0.1)
    return t - this.now
  }

  whisper(pos: Vec | null, seconds = 1.6, volume = 0.6, pan = 0) {
    if (!this.ready) return
    const ctx = this.ctx
    const src = this.noiseSource(true)
    const bp = ctx.createBiquadFilter()
    bp.type = 'bandpass'
    bp.Q.value = 5
    const bp2 = ctx.createBiquadFilter()
    bp2.type = 'bandpass'
    bp2.Q.value = 3
    const g = ctx.createGain()
    g.gain.value = 0
    const o = this.out(pos, { reverb: 0.15, pan, refDistance: 0.6 })
    const mix = ctx.createGain()
    src.connect(bp).connect(mix)
    src.connect(bp2).connect(mix)
    mix.connect(g).connect(o.input)
    let t = this.now + 0.02
    const end = t + seconds
    while (t < end) {
      const syl = rand(0.07, 0.18)
      bp.frequency.setValueAtTime(rand(1400, 3800), t)
      bp2.frequency.setValueAtTime(rand(500, 1200), t)
      g.gain.setValueAtTime(0, t)
      g.gain.linearRampToValueAtTime(volume * rand(0.5, 1), t + syl * 0.3)
      g.gain.linearRampToValueAtTime(volume * 0.1, t + syl)
      t += syl + (Math.random() < 0.2 ? rand(0.08, 0.2) : 0.01)
    }
    g.gain.linearRampToValueAtTime(0, t + 0.1)
    src.start()
    src.stop(t + 0.2)
  }

  knock(pos: Vec | null, volume = 0.9) {
    if (!this.ready) return
    const ctx = this.ctx
    const t = this.now
    const o = this.out(pos, { reverb: 1.2 })
    const osc = ctx.createOscillator()
    osc.frequency.setValueAtTime(190, t)
    osc.frequency.exponentialRampToValueAtTime(90, t + 0.12)
    const g = ctx.createGain()
    g.gain.setValueAtTime(volume, t)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.2)
    osc.connect(g).connect(o.input)
    osc.start(t)
    osc.stop(t + 0.25)
    const n = this.noiseSource()
    const bp = ctx.createBiquadFilter()
    bp.type = 'bandpass'
    bp.frequency.value = 1800
    const ng = ctx.createGain()
    ng.gain.setValueAtTime(volume * 0.8, t)
    ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.04)
    n.connect(bp).connect(ng).connect(o.input)
    n.start(t, Math.random(), 0.06)
  }

  creak(pos: Vec | null, seconds = 2.2, volume = 0.25) {
    if (!this.ready) return
    const ctx = this.ctx
    const t = this.now
    const osc = ctx.createOscillator()
    osc.type = 'sawtooth'
    osc.frequency.setValueAtTime(70, t)
    for (let i = 1; i < 12; i++) osc.frequency.linearRampToValueAtTime(rand(55, 140), t + (seconds * i) / 12)
    const bp = ctx.createBiquadFilter()
    bp.type = 'bandpass'
    bp.frequency.value = 900
    bp.Q.value = 4
    const g = ctx.createGain()
    g.gain.setValueAtTime(0, t)
    g.gain.linearRampToValueAtTime(volume, t + 0.2)
    g.gain.setValueAtTime(volume, t + seconds - 0.3)
    g.gain.linearRampToValueAtTime(0, t + seconds)
    const o = this.out(pos, { reverb: 0.6 })
    osc.connect(bp).connect(g).connect(o.input)
    osc.start(t)
    osc.stop(t + seconds + 0.1)
  }

  slam(pos: Vec | null, volume = 1) {
    if (!this.ready) return
    const ctx = this.ctx
    const t = this.now
    const o = this.out(pos, { reverb: 1.4 })
    const n = this.noiseSource()
    const lp = ctx.createBiquadFilter()
    lp.type = 'lowpass'
    lp.frequency.value = 500
    const g = ctx.createGain()
    g.gain.setValueAtTime(volume * 1.4, t)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.5)
    n.connect(lp).connect(g).connect(o.input)
    n.start(t, 0, 0.6)
    const osc = ctx.createOscillator()
    osc.frequency.setValueAtTime(60, t)
    osc.frequency.exponentialRampToValueAtTime(35, t + 0.4)
    const og = ctx.createGain()
    og.gain.setValueAtTime(volume, t)
    og.gain.exponentialRampToValueAtTime(0.0001, t + 0.5)
    osc.connect(og).connect(o.input)
    osc.start(t)
    osc.stop(t + 0.6)
  }

  click(pos: Vec | null, volume = 0.4) {
    if (!this.ready) return
    const ctx = this.ctx
    const t = this.now
    const o = this.out(pos, { reverb: 0.8 })
    const n = this.noiseSource()
    const hp = ctx.createBiquadFilter()
    hp.type = 'highpass'
    hp.frequency.value = 1200
    const g = ctx.createGain()
    g.gain.setValueAtTime(volume, t)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05)
    n.connect(hp).connect(g).connect(o.input)
    n.start(t, Math.random(), 0.06)
  }

  staticBurst(seconds = 0.8, volume = 0.18) {
    if (!this.ready) return
    const ctx = this.ctx
    const t = this.now
    const n = this.noiseSource(true)
    const bp = ctx.createBiquadFilter()
    bp.type = 'bandpass'
    bp.frequency.value = 2200
    bp.Q.value = 0.6
    const g = ctx.createGain()
    g.gain.setValueAtTime(0, t)
    for (let i = 0; i < seconds * 30; i++) g.gain.setValueAtTime(volume * Math.random(), t + i / 30)
    g.gain.setValueAtTime(0, t + seconds)
    const o = this.out(null, { reverb: 0.6 })
    n.connect(bp).connect(g).connect(o.input)
    n.start(t)
    n.stop(t + seconds + 0.05)
  }

  chime() {
    if (!this.ready) return 0
    const ctx = this.ctx
    const t = this.now
    const notes = [659.25, 523.25, 392]
    const o = this.out(null, { reverb: 1.6 })
    const bp = ctx.createBiquadFilter()
    bp.type = 'bandpass'
    bp.frequency.value = 1400
    bp.Q.value = 0.5
    bp.connect(o.input)
    notes.forEach((f, i) => {
      const osc = ctx.createOscillator()
      osc.frequency.value = f
      const g = ctx.createGain()
      const st = t + i * 0.55
      g.gain.setValueAtTime(0, st)
      g.gain.linearRampToValueAtTime(0.22, st + 0.02)
      g.gain.exponentialRampToValueAtTime(0.0001, st + 1.2)
      osc.connect(g).connect(bp)
      osc.start(st)
      osc.stop(st + 1.3)
    })
    return 1.9
  }

  ring(): () => void {
    if (!this.ready) return () => {}
    const ctx = this.ctx
    const g = ctx.createGain()
    g.gain.value = 0.08
    g.connect(this.sfx)
    let stopped = false
    const oscs: OscillatorNode[] = []
    const t0 = this.now
    for (let k = 0; k < 20; k++) {
      const st = t0 + k * 3
      for (let b = 0; b < 2; b++) {
        const bs = st + b * 0.45
        const o1 = ctx.createOscillator()
        o1.frequency.value = 1400
        const o2 = ctx.createOscillator()
        o2.frequency.value = 1750
        const eg = ctx.createGain()
        eg.gain.setValueAtTime(0, bs)
        eg.gain.linearRampToValueAtTime(1, bs + 0.02)
        eg.gain.setValueAtTime(1, bs + 0.35)
        eg.gain.linearRampToValueAtTime(0, bs + 0.38)
        o1.connect(eg)
        o2.connect(eg)
        eg.connect(g)
        o1.start(bs)
        o2.start(bs)
        o1.stop(bs + 0.4)
        o2.stop(bs + 0.4)
        oscs.push(o1, o2)
      }
    }
    return () => {
      if (stopped) return
      stopped = true
      g.gain.setTargetAtTime(0, this.now, 0.01)
      setTimeout(() => oscs.forEach((o) => { try { o.stop() } catch {} }), 100)
    }
  }

  ping() {
    if (!this.ready) return
    const ctx = this.ctx
    const t = this.now
    ;[1318.5, 1760].forEach((f, i) => {
      const o = ctx.createOscillator()
      o.frequency.value = f
      const g = ctx.createGain()
      const st = t + i * 0.12
      g.gain.setValueAtTime(0, st)
      g.gain.linearRampToValueAtTime(0.09, st + 0.01)
      g.gain.exponentialRampToValueAtTime(0.0001, st + 0.4)
      o.connect(g).connect(this.sfx)
      o.start(st)
      o.stop(st + 0.45)
    })
  }

  sting(volume = 0.7) {
    if (!this.ready) return
    const ctx = this.ctx
    const t = this.now
    const g = ctx.createGain()
    g.gain.setValueAtTime(0, t)
    g.gain.linearRampToValueAtTime(volume, t + 0.03)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.6)
    g.connect(this.sfx)
    const send = ctx.createGain()
    send.gain.value = 0.8
    g.connect(send).connect(this.reverbSend)
    ;[233, 247, 311, 466, 494].forEach((f) => {
      const o = ctx.createOscillator()
      o.type = 'sawtooth'
      o.frequency.setValueAtTime(f, t)
      o.frequency.linearRampToValueAtTime(f * 1.06, t + 1.4)
      const og = ctx.createGain()
      og.gain.value = 0.12
      o.connect(og).connect(g)
      o.start(t)
      o.stop(t + 1.7)
    })
    const n = this.noiseSource()
    const ng = ctx.createGain()
    ng.gain.value = 0.5
    n.connect(ng).connect(g)
    n.start(t, 0, 1.6)
  }

  heartbeat(intensity: number, gameTime: number) {
    if (!this.ready || intensity < 0.55) return
    if (gameTime < this.heartbeatNext) return
    const bpm = 70 + intensity * 70
    this.heartbeatNext = gameTime + 60 / bpm
    const ctx = this.ctx
    const t = this.now
    const vol = (intensity - 0.5) * 0.5
    ;[0, 0.16].forEach((off, i) => {
      const o = ctx.createOscillator()
      o.frequency.setValueAtTime(55, t + off)
      o.frequency.exponentialRampToValueAtTime(30, t + off + 0.15)
      const g = ctx.createGain()
      g.gain.setValueAtTime(vol * (i === 0 ? 1 : 0.7), t + off)
      g.gain.exponentialRampToValueAtTime(0.0001, t + off + 0.18)
      o.connect(g).connect(this.sfx)
      o.start(t + off)
      o.stop(t + off + 0.2)
    })
  }

  train(): { panner: PannerNode; stop: (fade?: number) => void } | null {
    if (!this.ready) return null
    const ctx = this.ctx
    const t = this.now
    const o = this.out({ x: 0, y: 0, z: 100 }, { reverb: 0.5, refDistance: 6 })
    const panner = o.panner as PannerNode
    const master = ctx.createGain()
    master.gain.setValueAtTime(0, t)
    master.gain.linearRampToValueAtTime(1, t + 3)
    master.connect(o.input)
    const n = this.noiseSource(true)
    const lp = ctx.createBiquadFilter()
    lp.type = 'lowpass'
    lp.frequency.value = 260
    const ng = ctx.createGain()
    ng.gain.value = 1.4
    n.connect(lp).connect(ng).connect(master)
    n.start(t)
    const sq = ctx.createBufferSource()
    sq.buffer = this.noise
    sq.loop = true
    const sbp = ctx.createBiquadFilter()
    sbp.type = 'bandpass'
    sbp.frequency.value = 3200
    sbp.Q.value = 8
    const sg = ctx.createGain()
    sg.gain.value = 0.25
    sq.connect(sbp).connect(sg).connect(master)
    sq.start(t)
    const clacks: AudioScheduledSourceNode[] = []
    for (let k = 0; k < 60; k++) {
      const st = t + k * 0.42 + (k % 2) * 0.12
      const cn = this.noiseSource()
      const cbp = ctx.createBiquadFilter()
      cbp.type = 'bandpass'
      cbp.frequency.value = 700
      const cg = ctx.createGain()
      cg.gain.setValueAtTime(0.9, st)
      cg.gain.exponentialRampToValueAtTime(0.0001, st + 0.08)
      cn.connect(cbp).connect(cg).connect(master)
      cn.start(st, Math.random(), 0.1)
      clacks.push(cn)
    }
    return {
      panner,
      stop: (fade = 2) => {
        const now = this.now
        master.gain.cancelScheduledValues(now)
        master.gain.setValueAtTime(master.gain.value, now)
        master.gain.linearRampToValueAtTime(0, now + fade)
        setTimeout(() => {
          try { n.stop(); sq.stop() } catch {}
          clacks.forEach((c) => { try { c.stop() } catch {} })
        }, fade * 1000 + 100)
      },
    }
  }

  horn(pos: Vec | null, seconds = 2.6, volume = 0.45) {
    if (!this.ready) return
    const ctx = this.ctx
    const t = this.now
    const o = this.out(pos, { reverb: 1.6, refDistance: 10 })
    const lp = ctx.createBiquadFilter()
    lp.type = 'lowpass'
    lp.frequency.value = 1600
    const g = ctx.createGain()
    g.gain.setValueAtTime(0, t)
    g.gain.linearRampToValueAtTime(volume, t + 0.15)
    g.gain.setValueAtTime(volume, t + seconds - 0.4)
    g.gain.linearRampToValueAtTime(0, t + seconds)
    lp.connect(g).connect(o.input)
    ;[311, 370, 466].forEach((f) => {
      const osc = ctx.createOscillator()
      osc.type = 'sawtooth'
      osc.frequency.value = f
      osc.detune.value = rand(-8, 8)
      const og = ctx.createGain()
      og.gain.value = 0.2
      osc.connect(og).connect(lp)
      osc.start(t)
      osc.stop(t + seconds + 0.1)
    })
  }

  flicker(pos: Vec | null) {
    if (!this.ready) return
    const ctx = this.ctx
    const t = this.now
    const o = this.out(pos, { reverb: 0.4 })
    const osc = ctx.createOscillator()
    osc.type = 'square'
    osc.frequency.value = 120
    const g = ctx.createGain()
    g.gain.setValueAtTime(0, t)
    for (let i = 0; i < 8; i++) g.gain.setValueAtTime(Math.random() < 0.5 ? 0.04 : 0, t + i * 0.04)
    g.gain.setValueAtTime(0, t + 0.35)
    osc.connect(g).connect(o.input)
    osc.start(t)
    osc.stop(t + 0.4)
  }

  speak(text: string, opts: { pitch?: number; rate?: number; volume?: number } = {}): Promise<void> {
    return new Promise((resolve) => {
      const fallback = window.setTimeout(resolve, 900 + text.length * 85)
      if (typeof speechSynthesis === 'undefined') return
      try {
        const u = new SpeechSynthesisUtterance(text)
        const voices = speechSynthesis.getVoices()
        const voice =
          voices.find((v) => v.lang === 'hi-IN') ||
          voices.find((v) => v.lang === 'en-IN') ||
          voices.find((v) => v.lang.startsWith('en'))
        if (voice) {
          u.voice = voice
          u.lang = voice.lang
        }
        u.pitch = opts.pitch ?? 0.6
        u.rate = opts.rate ?? 0.78
        u.volume = opts.volume ?? 0.85
        u.onend = () => {
          clearTimeout(fallback)
          resolve()
        }
        speechSynthesis.speak(u)
      } catch {
        // speech unavailable — subtitles carry the line
      }
    })
  }
}
