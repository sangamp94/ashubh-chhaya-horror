import * as THREE from 'three'
import { AudioEngine } from './audio'
import { hud, type Subtitle } from './hud-store'
import { LAYER, animateAvatar, makeAvatar, makeGirl, makeTrain, type Avatar, type Girl, type Train } from './entities'
import { World, type Region } from './world'
import { FearDirector, BehindPlayerDirector } from './directors'
import { Story } from './story'

export type GirlRule = {
  mode: 'static' | 'vanishOnLook'
  lookAngle: number
  dwell: number
  dwellNeeded: number
  minTime: number
  maxTime: number
  t: number
  facePlayer: boolean
  blinkVanish?: boolean
  onVanish?: (reason: 'look' | 'timeout') => void
}

export type Interactable = {
  id: string
  pos: THREE.Vector3
  radius: number
  prompt: string
  enabled: boolean
  onUse: () => void
}

type Timer = { at: number; resolve: () => void }
type Waiter = { pred: () => boolean; resolve: (v: boolean) => void; deadline: number }

const tmpV = new THREE.Vector3()
const tmpV2 = new THREE.Vector3()

export class Game {
  container: HTMLElement
  renderer: THREE.WebGLRenderer
  scene = new THREE.Scene()
  camera: THREE.PerspectiveCamera
  selfieCam: THREE.PerspectiveCamera
  photoCam: THREE.PerspectiveCamera
  cctvCam: THREE.PerspectiveCamera
  roomCam: THREE.PerspectiveCamera
  cctvRT: THREE.WebGLRenderTarget
  world: World
  audio = new AudioEngine()
  fear: FearDirector
  behind: BehindPlayerDirector
  story: Story

  girl: Girl
  girlCam: Girl
  girlReflect: Girl
  girlCctv: Girl
  girlRules = new Map<Girl, GirlRule>()
  avatar: Avatar
  pastAvatar: Avatar
  avatarOverride = false
  train: Train

  flashlight: THREE.SpotLight
  flashOn = true
  flashBroken = 0

  player = {
    pos: new THREE.Vector3(0, 0, 26),
    vel: new THREE.Vector3(),
    yaw: 0,
    pitch: 0,
    stepDist: 0,
    bob: 0,
    running: false,
    speed: 0,
  }
  lockMove = false
  lockLook = false
  forced: { yaw: number; pitch: number; rate: number } | null = null
  region: Region = 'platform'
  private lastIndoor = false

  time = 0
  paused = true
  started = false
  private timers: Timer[] = []
  private waiters: Waiter[] = []
  private keys = new Set<string>()
  private mouseDown = false
  lockUnavailable = false
  private raf = 0
  private last = 0
  private shakeAmt = 0
  private subtitleToken = 0

  cameraMode = false
  selfie = false
  cameraOpenCount = 0
  onCameraToggle: ((open: boolean) => void) | null = null
  onFlashToggle: ((on: boolean) => void) | null = null
  stepListeners: Array<() => void> = []

  cctv = { active: false, which: 'platform' as 'platform' | 'room', power: 1, frame: 0 }

  interactables: Interactable[] = []
  globalAction: { prompt: string; fn: () => void } | null = null
  private currentInteract: Interactable | null = null
  noteResolve: (() => void) | null = null

  yawHistory: { t: number; yaw: number }[] = []
  lookBehindCount = 0
  lookBehindSinceScare = 0
  lastLookBehind = -999
  lookBehindListeners: Array<() => void> = []

  clockMinutes = 14
  clockFrozen = false
  private clockAccum = 0

  constructor(container: HTMLElement) {
    this.container = container
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' })
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5))
    this.renderer.setSize(container.clientWidth, container.clientHeight)
    this.renderer.shadowMap.enabled = true
    this.renderer.shadowMap.type = THREE.PCFShadowMap
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping
    this.renderer.toneMappingExposure = 1.05
    this.renderer.outputColorSpace = THREE.SRGBColorSpace
    container.appendChild(this.renderer.domElement)
    this.renderer.domElement.style.display = 'block'
    this.renderer.domElement.style.transition = 'filter 0.3s'

    const aspect = container.clientWidth / container.clientHeight
    this.camera = new THREE.PerspectiveCamera(70, aspect, 0.05, 220)
    this.camera.rotation.order = 'YXZ'
    this.camera.layers.set(LAYER.DEFAULT)
    this.scene.add(this.camera)
    this.selfieCam = new THREE.PerspectiveCamera(65, aspect, 0.05, 120)
    this.selfieCam.layers.set(LAYER.DEFAULT)
    this.selfieCam.layers.enable(LAYER.AVATAR)
    this.selfieCam.layers.enable(LAYER.CAMERA_ONLY)
    this.photoCam = new THREE.PerspectiveCamera(60, aspect, 0.05, 160)
    this.photoCam.layers.set(LAYER.DEFAULT)
    this.photoCam.layers.enable(LAYER.AVATAR)
    this.cctvCam = new THREE.PerspectiveCamera(62, 4 / 3, 0.1, 60)
    this.cctvCam.layers.set(LAYER.DEFAULT)
    this.cctvCam.layers.enable(LAYER.AVATAR)
    this.cctvCam.layers.enable(LAYER.CCTV_ONLY)
    this.roomCam = this.cctvCam.clone()
    this.cctvRT = new THREE.WebGLRenderTarget(512, 384)

    this.scene.background = new THREE.Color(0x05070a)
    this.scene.fog = new THREE.FogExp2(0x05070a, 0.055)

    this.world = new World(this.scene)
    this.world.build()

    this.flashlight = new THREE.SpotLight(0xfff4e0, 16, 30, 0.44, 0.6, 1.35)
    this.flashlight.position.set(0.18, -0.2, 0.1)
    this.flashlight.castShadow = true
    this.flashlight.shadow.mapSize.set(1024, 1024)
    this.flashlight.shadow.camera.near = 0.3
    this.flashlight.shadow.bias = -0.0005
    this.camera.add(this.flashlight)
    this.flashlight.target.position.set(0, -0.3, -6)
    this.camera.add(this.flashlight.target)

    this.girl = makeGirl(LAYER.DEFAULT)
    this.girlCam = makeGirl(LAYER.CAMERA_ONLY)
    this.girlReflect = makeGirl(LAYER.REFLECT_ONLY)
    this.girlCctv = makeGirl(LAYER.CCTV_ONLY)
    for (const g of [this.girl, this.girlCam, this.girlReflect, this.girlCctv]) this.scene.add(g)
    this.avatar = makeAvatar(LAYER.AVATAR)
    this.scene.add(this.avatar)
    this.pastAvatar = makeAvatar(LAYER.CCTV_ONLY)
    this.pastAvatar.visible = false
    this.scene.add(this.pastAvatar)
    this.train = makeTrain()
    this.train.position.set(6.5, -0.6, 140)
    this.scene.add(this.train)

    const reflectCam = this.world.mirror.getReflectionCamera(this.camera)
    reflectCam.layers.enable(LAYER.AVATAR)
    reflectCam.layers.enable(LAYER.REFLECT_ONLY)

    this.fear = new FearDirector(this)
    this.behind = new BehindPlayerDirector(this)
    this.story = new Story(this)

    this.bindInput()
    this.world.clock.draw(2, 14)
    this.updateCamera(0)
    this.renderer.render(this.scene, this.camera)
    this.renderer.compile(this.scene, this.camera)
  }

  // ---------- lifecycle ----------
  start() {
    this.audio.init()
    this.audio.resume()
    this.requestLock()
    if (!this.started) {
      this.started = true
      this.paused = false
      hud.set({ phase: 'playing' })
      this.last = performance.now()
      this.raf = requestAnimationFrame(this.loop)
      this.story.run()
    } else this.resume()
  }

  resume() {
    if (!this.paused) return
    this.paused = false
    this.audio.unsuspend()
    this.last = performance.now()
    hud.set({ phase: 'playing' })
  }

  pause() {
    if (this.paused || hud.getState().phase === 'ended') return
    this.paused = true
    this.audio.suspend()
    hud.set({ phase: 'paused' })
  }

  requestLock() {
    const el = this.renderer.domElement
    try {
      const p = el.requestPointerLock() as unknown as Promise<void> | undefined
      if (p && typeof p.catch === 'function') p.catch(() => this.markLockUnavailable())
    } catch {
      this.markLockUnavailable()
    }
  }

  private markLockUnavailable() {
    this.lockUnavailable = true
    hud.set({ lockUnavailable: true })
  }

  dispose() {
    cancelAnimationFrame(this.raf)
    this.audio.stopAll()
    window.removeEventListener('keydown', this.onKeyDown)
    window.removeEventListener('keyup', this.onKeyUp)
    window.removeEventListener('mousemove', this.onMouseMove)
    window.removeEventListener('mousedown', this.onMouseDown)
    window.removeEventListener('mouseup', this.onMouseUp)
    window.removeEventListener('resize', this.onResize)
    document.removeEventListener('pointerlockchange', this.onLockChange)
    document.removeEventListener('pointerlockerror', this.onLockError)
    this.renderer.dispose()
    this.renderer.domElement.remove()
  }

  // ---------- input ----------
  private bindInput() {
    window.addEventListener('keydown', this.onKeyDown)
    window.addEventListener('keyup', this.onKeyUp)
    window.addEventListener('mousemove', this.onMouseMove)
    window.addEventListener('mousedown', this.onMouseDown)
    window.addEventListener('mouseup', this.onMouseUp)
    window.addEventListener('resize', this.onResize)
    document.addEventListener('pointerlockchange', this.onLockChange)
    document.addEventListener('pointerlockerror', this.onLockError)
  }

  private onLockChange = () => {
    if (document.pointerLockElement !== this.renderer.domElement && this.started && !this.lockUnavailable) this.pause()
  }
  private onLockError = () => this.markLockUnavailable()

  private onResize = () => {
    const w = this.container.clientWidth
    const h = this.container.clientHeight
    this.renderer.setSize(w, h)
    for (const c of [this.camera, this.selfieCam, this.photoCam]) {
      c.aspect = w / h
      c.updateProjectionMatrix()
    }
  }

  private onKeyDown = (e: KeyboardEvent) => {
    if (!this.started) return
    const k = e.code
    if (k === 'Escape' && this.lockUnavailable) {
      if (this.paused) this.resume()
      else this.pause()
      return
    }
    if (this.paused) return
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(k)) e.preventDefault()
    this.keys.add(k)
    if (e.repeat) return
    if (k === 'KeyE') this.interact()
    if (k === 'KeyF') this.toggleFlashlight()
    if (k === 'KeyC') this.toggleCamera()
  }
  private onKeyUp = (e: KeyboardEvent) => this.keys.delete(e.code)
  private onMouseDown = (e: MouseEvent) => {
    if (e.button === 0) this.mouseDown = true
    if (this.noteResolve && !this.paused) this.closeNote()
  }
  private onMouseUp = () => {
    this.mouseDown = false
  }
  private onMouseMove = (e: MouseEvent) => {
    if (this.paused || this.lockLook || this.forced) return
    const locked = document.pointerLockElement === this.renderer.domElement
    if (!locked && !(this.lockUnavailable && this.mouseDown)) return
    const sens = locked ? 0.0022 : 0.004
    this.player.yaw -= e.movementX * sens
    this.player.pitch -= e.movementY * sens
    this.player.pitch = THREE.MathUtils.clamp(this.player.pitch, -1.35, 1.35)
  }

  interact() {
    if (this.noteResolve) {
      this.closeNote()
      return
    }
    if (this.globalAction) {
      const fn = this.globalAction.fn
      this.globalAction = null
      fn()
      return
    }
    if (this.currentInteract && !this.lockMove) {
      const it = this.currentInteract
      it.enabled = false
      this.currentInteract = null
      it.onUse()
    }
  }

  toggleFlashlight(force?: boolean) {
    this.flashOn = force ?? !this.flashOn
    this.audio.click(null, 0.25)
    hud.set({ flashlight: this.flashOn })
    this.onFlashToggle?.(this.flashOn)
  }

  toggleCamera(force?: boolean) {
    const open = force ?? !this.cameraMode
    if (open === this.cameraMode) return
    if (hud.getState().cameraDrop) return
    this.cameraMode = open
    if (open) {
      this.camera.layers.enable(LAYER.CAMERA_ONLY)
      this.cameraOpenCount++
      this.audio.click(null, 0.15)
    } else {
      this.camera.layers.disable(LAYER.CAMERA_ONLY)
      this.selfie = false
    }
    this.renderer.toneMappingExposure = open ? 2.1 : 1.05
    this.renderer.domElement.style.filter = open ? 'saturate(0.35) contrast(1.15) brightness(1.05)' : ''
    hud.set({ cameraMode: open, selfie: this.selfie })
    this.onCameraToggle?.(open)
  }

  addInteractable(it: Omit<Interactable, 'enabled'> & { enabled?: boolean }) {
    const full: Interactable = { enabled: true, ...it }
    this.interactables.push(full)
    return full
  }

  showNote(title: string, body: string) {
    hud.set({ note: { title, body } })
    this.lockMove = true
    this.audio.click(null, 0.1)
    return new Promise<void>((resolve) => {
      this.noteResolve = resolve
    })
  }

  closeNote() {
    hud.set({ note: null })
    this.lockMove = false
    const r = this.noteResolve
    this.noteResolve = null
    r?.()
  }

  // ---------- time helpers ----------
  wait(seconds: number) {
    return new Promise<void>((resolve) => this.timers.push({ at: this.time + seconds, resolve }))
  }

  waitUntil(pred: () => boolean, timeout = Infinity) {
    return new Promise<boolean>((resolve) => this.waiters.push({ pred, resolve, deadline: this.time + timeout }))
  }

  // ---------- spatial helpers ----------
  head() {
    return this.camera.position
  }

  lookDir(out = new THREE.Vector3()) {
    return out.set(0, 0, -1).applyEuler(new THREE.Euler(this.player.pitch, this.player.yaw, 0, 'YXZ'))
  }

  flatForward(out = new THREE.Vector3()) {
    return out.set(-Math.sin(this.player.yaw), 0, -Math.cos(this.player.yaw))
  }

  angleTo(p: THREE.Vector3) {
    const d = tmpV.copy(p).sub(this.head()).normalize()
    return this.lookDir(tmpV2).angleTo(d)
  }

  flatAngleTo(p: THREE.Vector3) {
    const dx = p.x - this.player.pos.x
    const dz = p.z - this.player.pos.z
    const f = this.flatForward(tmpV2)
    const len = Math.hypot(dx, dz) || 1
    return Math.acos(THREE.MathUtils.clamp((f.x * dx + f.z * dz) / len, -1, 1))
  }

  distTo(p: THREE.Vector3) {
    return Math.hypot(p.x - this.player.pos.x, p.z - this.player.pos.z)
  }

  /** Point on the floor behind the player (relative to current facing). */
  behindPoint(dist: number, lateral = 0) {
    const f = this.flatForward(new THREE.Vector3())
    const right = new THREE.Vector3(-f.z, 0, f.x)
    return new THREE.Vector3(
      this.player.pos.x - f.x * dist + right.x * lateral,
      this.player.pos.y,
      this.player.pos.z - f.z * dist + right.z * lateral,
    )
  }

  aheadPoint(dist: number, lateral = 0) {
    return this.behindPoint(-dist, -lateral)
  }

  lineOfSight(p: THREE.Vector3) {
    const dx = p.x - this.player.pos.x
    const dz = p.z - this.player.pos.z
    const d = Math.hypot(dx, dz)
    for (let s = 0.6; s < d - 0.4; s += 0.4) {
      if (this.world.blocked(this.player.pos.x + (dx / d) * s, this.player.pos.z + (dz / d) * s, this.player.pos.y + 0.6, 0)) return false
    }
    return true
  }

  spotFree(p: THREE.Vector3) {
    return !this.world.blocked(p.x, p.z, p.y, 0.25) && this.lineOfSight(p)
  }

  isLit() {
    if (this.region === 'office' || this.region === 'hall') return true
    for (const k in this.world.lamps) {
      const l = this.world.lamps[k]
      if (!l.on) continue
      if (l.light.position.distanceTo(this.head()) < l.light.distance * 0.35) return true
    }
    return false
  }

  // ---------- girl control ----------
  showGirl(g: Girl, pos: THREE.Vector3, rule: Partial<GirlRule> = {}) {
    g.position.copy(pos)
    g.visible = true
    const full: GirlRule = {
      mode: 'vanishOnLook',
      lookAngle: 0.18,
      dwell: 0,
      dwellNeeded: 0,
      minTime: 0,
      maxTime: Infinity,
      t: 0,
      facePlayer: true,
      ...rule,
    }
    this.girlRules.set(g, full)
    if (full.facePlayer) this.faceGirl(g)
  }

  hideGirl(g: Girl) {
    g.visible = false
    this.girlRules.delete(g)
  }

  faceGirl(g: Girl, target: THREE.Vector3 = this.player.pos) {
    g.rotation.y = Math.atan2(target.x - g.position.x, target.z - g.position.z)
  }

  private updateGirls(dt: number) {
    for (const [g, r] of this.girlRules) {
      if (!g.visible) {
        this.girlRules.delete(g)
        continue
      }
      r.t += dt
      if (r.facePlayer) this.faceGirl(g)
      if (r.mode === 'vanishOnLook' && r.t >= r.minTime) {
        const headP = tmpV.set(g.position.x, g.position.y + 1.4, g.position.z)
        const looking = this.angleTo(headP) < r.lookAngle && (g === this.girl ? this.lineOfSight(g.position) : true)
        if (looking) r.dwell += dt
        if (looking && r.dwell >= r.dwellNeeded) {
          if (r.blinkVanish) {
            r.mode = 'static'
            r.maxTime = Infinity
            hud.set({ fade: 1, fadeMs: 40 })
            this.wait(0.09).then(() => {
              this.hideGirl(g)
              hud.set({ fade: 0, fadeMs: 140 })
              r.onVanish?.('look')
            })
          } else {
            this.hideGirl(g)
            r.onVanish?.('look')
          }
          continue
        }
      }
      if (r.t > r.maxTime) {
        this.hideGirl(g)
        r.onVanish?.('timeout')
      }
    }
  }

  // ---------- effects ----------
  shake(a: number) {
    this.shakeAmt = Math.max(this.shakeAmt, a)
  }

  async blink(ms = 140) {
    hud.set({ fade: 1, fadeMs: 40 })
    await this.wait(ms / 1000)
    hud.set({ fade: 0, fadeMs: 120 })
  }

  async fadeTo(v: number, seconds: number) {
    hud.set({ fade: v, fadeMs: seconds * 1000 })
    await this.wait(seconds)
  }

  say(sub: Subtitle, seconds = 3) {
    const token = ++this.subtitleToken
    hud.set({ subtitle: sub })
    this.wait(seconds).then(() => {
      if (token === this.subtitleToken) hud.set({ subtitle: null })
    })
  }

  async announce(text: string, translation?: string, voice = { pitch: 0.5, rate: 0.72 }) {
    const prev = this.ambientLevel
    this.audio.setAmbient(prev * 0.6, 0.5)
    await this.wait(this.audio.chime())
    this.audio.staticBurst(0.5, 0.12)
    this.say({ speaker: 'Station announcement', text, translation }, 3 + text.length * 0.07)
    await Promise.race([this.audio.speak(text, voice), this.wait(2 + text.length * 0.12)])
    this.audio.staticBurst(0.3, 0.1)
    this.audio.setAmbient(this.ambientLevel, 2)
  }

  ambientLevel = 1
  setAmbient(level: number, seconds = 1.5) {
    this.ambientLevel = level
    this.audio.setAmbient(level, seconds)
  }

  setObjective(text: string) {
    hud.set({ objective: text, objectiveKey: hud.getState().objectiveKey + 1 })
  }

  forceLook(target: THREE.Vector3, rate = 3) {
    const d = tmpV.copy(target).sub(this.head())
    const yaw = Math.atan2(-d.x, -d.z)
    const pitch = Math.atan2(d.y, Math.hypot(d.x, d.z))
    this.forced = { yaw, pitch, rate }
  }

  releaseLook() {
    this.forced = null
  }

  setFlashBroken(seconds: number) {
    this.flashBroken = seconds
  }

  renderCctv() {
    const cam = this.cctv.which === 'platform' ? this.cctvCam : this.roomCam
    const prevTarget = this.renderer.getRenderTarget()
    const prevExposure = this.renderer.toneMappingExposure
    const mirrorVisible = this.world.mirror.visible
    this.world.mirror.visible = false
    const flash = this.flashlight.visible
    this.renderer.setRenderTarget(this.cctvRT)
    this.renderer.render(this.scene, cam)
    this.renderer.setRenderTarget(prevTarget)
    this.renderer.toneMappingExposure = prevExposure
    this.world.mirror.visible = mirrorVisible
    this.flashlight.visible = flash
    this.world.cctvMaterial.uniforms.tDiffuse.value = this.cctvRT.texture
    this.world.cctvMaterial.uniforms.power.value = this.cctv.power
  }

  renderPhoto(target: THREE.WebGLRenderTarget, cam: THREE.Camera) {
    const prev = this.renderer.getRenderTarget()
    this.world.mirror.visible = false
    this.renderer.setRenderTarget(target)
    this.renderer.render(this.scene, cam)
    this.renderer.setRenderTarget(prev)
  }

  snapshot(cam: THREE.Camera) {
    this.world.mirror.visible = false
    this.renderer.render(this.scene, cam)
    return this.renderer.domElement.toDataURL('image/jpeg', 0.88)
  }

  // ---------- loop ----------
  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop)
    const dt = Math.min(0.05, (now - this.last) / 1000)
    this.last = now
    if (this.paused) return
    this.time += dt
    this.update(dt)
    this.render()
  }

  private update(dt: number) {
    // timers & waiters
    if (this.timers.length) {
      const due = this.timers.filter((t) => t.at <= this.time)
      if (due.length) {
        this.timers = this.timers.filter((t) => t.at > this.time)
        due.forEach((t) => t.resolve())
      }
    }
    if (this.waiters.length) {
      const keep: Waiter[] = []
      for (const w of this.waiters) {
        if (w.pred()) w.resolve(true)
        else if (this.time > w.deadline) w.resolve(false)
        else keep.push(w)
      }
      this.waiters = keep
    }

    this.updatePlayer(dt)
    this.updateCamera(dt)
    this.updateLookTracking()
    this.updateAvatar(dt)
    this.updateGirls(dt)
    this.world.update(dt, this.time)
    this.updateFlashlight(dt)
    this.updateInteract()
    this.fear.update(dt)
    this.behind.update(dt)
    this.story.update(dt)

    const r = this.world.region(this.player.pos.x, this.player.pos.z, this.player.pos.y)
    this.region = r
    const indoor = this.world.isIndoor(r)
    if (indoor !== this.lastIndoor) {
      this.lastIndoor = indoor
      this.audio.setIndoor(indoor)
    }
    this.world.mirror.visible = r === 'office'

    if (!this.clockFrozen) {
      this.clockAccum += dt
      if (this.clockAccum > 75) {
        this.clockAccum = 0
        this.clockMinutes++
        this.world.clock.draw(2, this.clockMinutes)
      }
    }
    hud.set({ clock: `2:${String(this.clockMinutes).padStart(2, '0')}` })

    const f = this.lookDir(tmpV2)
    this.audio.updateListener(this.camera, f)
  }

  private updatePlayer(dt: number) {
    const p = this.player
    const k = this.keys
    let fx = 0
    let fz = 0
    if (!this.lockMove) {
      if (k.has('KeyW') || k.has('ArrowUp')) fz += 1
      if (k.has('KeyS') || k.has('ArrowDown')) fz -= 1
      if (k.has('KeyA')) fx -= 1
      if (k.has('KeyD')) fx += 1
      if (!this.forced && !this.lockLook) {
        if (k.has('ArrowLeft')) p.yaw += dt * 2.2
        if (k.has('ArrowRight')) p.yaw -= dt * 2.2
      }
    }
    p.running = (k.has('ShiftLeft') || k.has('ShiftRight')) && fz > 0 && !this.cameraMode
    const speed = this.cameraMode ? 1.3 : p.running ? 4.1 : 2.1
    const fwd = this.flatForward(tmpV)
    const rx = -fwd.z
    const rz = fwd.x
    let tx = fwd.x * fz + rx * fx
    let tz = fwd.z * fz + rz * fx
    const len = Math.hypot(tx, tz)
    if (len > 0) {
      tx = (tx / len) * speed
      tz = (tz / len) * speed
    }
    const a = 1 - Math.exp(-dt * 9)
    p.vel.x += (tx - p.vel.x) * a
    p.vel.z += (tz - p.vel.z) * a
    p.pos.x += p.vel.x * dt
    p.pos.z += p.vel.z * dt
    this.resolveCollisions()
    const fy = this.world.floorAt(p.pos.x, p.pos.z, p.pos.y)
    p.pos.y += (fy - p.pos.y) * Math.min(1, dt * 14)
    p.speed = Math.hypot(p.vel.x, p.vel.z)

    p.stepDist += p.speed * dt
    const stride = p.running ? 1.05 : 0.78
    if (p.stepDist > stride) {
      p.stepDist = 0
      const indoor = this.world.isIndoor(this.region)
      this.audio.footstep(null, p.running ? 0.55 : 0.38, !indoor && this.region !== 'bridge')
      this.stepListeners.forEach((l) => l())
    }
    p.bob += p.speed * dt * 4.1
  }

  private resolveCollisions() {
    const p = this.player.pos
    const r = 0.3
    for (let it = 0; it < 2; it++) {
      for (const c of this.world.colliders) {
        if (!c.enabled) continue
        if (c.minY > p.y + 1.7 || c.maxY < p.y + 0.3) continue
        const cx = Math.max(c.minX, Math.min(p.x, c.maxX))
        const cz = Math.max(c.minZ, Math.min(p.z, c.maxZ))
        const dx = p.x - cx
        const dz = p.z - cz
        const d2 = dx * dx + dz * dz
        if (d2 >= r * r) continue
        if (d2 > 1e-9) {
          const d = Math.sqrt(d2)
          p.x += (dx / d) * (r - d)
          p.z += (dz / d) * (r - d)
        } else {
          const pen = [p.x - c.minX + r, c.maxX - p.x + r, p.z - c.minZ + r, c.maxZ - p.z + r]
          const i = pen.indexOf(Math.min(...pen))
          if (i === 0) p.x = c.minX - r
          else if (i === 1) p.x = c.maxX + r
          else if (i === 2) p.z = c.minZ - r
          else p.z = c.maxZ + r
        }
      }
    }
  }

  private updateCamera(dt: number) {
    const p = this.player
    if (this.forced) {
      const f = this.forced
      let dy = f.yaw - p.yaw
      dy = Math.atan2(Math.sin(dy), Math.cos(dy))
      const a = 1 - Math.exp(-dt * f.rate)
      p.yaw += dy * a
      p.pitch += (f.pitch - p.pitch) * a
    }
    const bobAmt = Math.min(1, p.speed / 2.2)
    const bobY = Math.sin(p.bob * 2) * 0.03 * bobAmt
    const bobX = Math.cos(p.bob) * 0.02 * bobAmt
    this.shakeAmt = Math.max(0, this.shakeAmt - dt * 1.5)
    const s = this.shakeAmt
    this.camera.position.set(p.pos.x + bobX * Math.cos(p.yaw), p.pos.y + 1.62 + bobY, p.pos.z - bobX * Math.sin(p.yaw))
    this.camera.rotation.set(
      p.pitch + (Math.random() - 0.5) * s * 0.05,
      p.yaw + (Math.random() - 0.5) * s * 0.05,
      (Math.random() - 0.5) * s * 0.03 + bobX * 0.15,
    )
  }

  private updateLookTracking() {
    const h = this.yawHistory
    h.push({ t: this.time, yaw: this.player.yaw })
    while (h.length && h[0].t < this.time - 0.9) h.shift()
    if (this.time - this.lastLookBehind < 1.6 || h.length < 2) return
    const delta = Math.abs(this.player.yaw - h[0].yaw)
    if (delta > 2.1) {
      this.lastLookBehind = this.time
      this.lookBehindCount++
      this.lookBehindSinceScare++
      this.lookBehindListeners.forEach((l) => l())
    }
  }

  private updateAvatar(dt: number) {
    const a = this.avatar
    if (!this.avatarOverride) {
      a.position.copy(this.player.pos)
      a.rotation.y = this.player.yaw + Math.PI
      animateAvatar(a, this.player.bob, Math.min(1, this.player.speed / 2))
    }
    void dt
  }

  private updateFlashlight(dt: number) {
    let on = this.flashOn
    if (this.flashBroken > 0) {
      this.flashBroken -= dt
      on = on && Math.random() < 0.35
    }
    this.flashlight.intensity = on ? 16 : 0
  }

  private updateInteract() {
    let prompt: string | null = null
    if (this.noteResolve) prompt = '[E] Close'
    else if (this.globalAction) prompt = this.globalAction.prompt
    else if (!this.lockMove) {
      let best: Interactable | null = null
      let bestScore = Infinity
      const head = this.head()
      for (const it of this.interactables) {
        if (!it.enabled) continue
        const d = it.pos.distanceTo(head)
        if (d > it.radius) continue
        const ang = this.angleTo(it.pos)
        if (ang > 0.5 && d > 0.9) continue
        const score = ang + d * 0.2
        if (score < bestScore) {
          best = it
          bestScore = score
        }
      }
      this.currentInteract = best
      if (best) prompt = best.prompt
    }
    hud.set({ prompt })
  }

  private render() {
    if (this.cctv.active && this.region === 'cctv') {
      this.cctv.frame++
      if (this.cctv.frame % 2 === 0) this.renderCctv()
    }
    if (this.selfie) {
      const head = this.head()
      const f = this.flatForward(tmpV)
      this.selfieCam.position.set(head.x + f.x * 0.55, head.y + 0.05, head.z + f.z * 0.55)
      this.selfieCam.lookAt(head.x - f.x * 1.5, head.y - 0.05, head.z - f.z * 1.5)
      this.renderer.render(this.scene, this.selfieCam)
      return
    }
    this.renderer.render(this.scene, this.camera)
  }
}
