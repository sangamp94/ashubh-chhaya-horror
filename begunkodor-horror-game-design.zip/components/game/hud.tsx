'use client'

import { useSyncExternalStore } from 'react'
import { hud } from '@/lib/game/hud-store'

function useHud() {
  return useSyncExternalStore(hud.subscribe, hud.getState, hud.getState)
}

export function Hud() {
  const s = useHud()
  const playing = s.phase === 'playing' || s.phase === 'paused'
  const urgent = s.objective !== '' && s.objective === s.objective.toUpperCase()

  return (
    <div className="pointer-events-none absolute inset-0 select-none overflow-hidden font-mono text-[#d9d4c7]">
      {/* fear vignette */}
      <div
        aria-hidden
        className="absolute inset-0 transition-[background] duration-700"
        style={{
          background: `radial-gradient(ellipse at center, transparent ${52 - s.fear * 22}%, rgba(0,0,0,${0.55 + s.fear * 0.4}) 100%)`,
        }}
      />
      <div aria-hidden className="grain absolute inset-[-50%] opacity-[0.09]" />

      {/* hand at the edge of the screen */}
      <img
        src="/images/hand.png"
        alt=""
        aria-hidden
        className="absolute left-0 top-1/2 h-[60vh] max-w-none -translate-y-1/2 mix-blend-screen transition-[transform,opacity] duration-150"
        style={{
          transform: `translate(${s.hand ? '-28%' : '-100%'}, -50%)`,
          opacity: s.hand ? 0.85 : 0,
          maskImage: 'linear-gradient(to right, black 60%, transparent)',
        }}
      />

      {playing && !s.cameraMode && (
        <div aria-hidden className="absolute left-1/2 top-1/2 h-[3px] w-[3px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#d9d4c7]/50" />
      )}

      {playing && s.objective && (
        <div key={s.objectiveKey} className="objective-in absolute left-6 top-6 max-w-sm md:left-10 md:top-9">
          <p className="mb-1 text-[10px] uppercase tracking-[0.35em] text-[#d9d4c7]/45">Objective</p>
          <p className={urgent ? 'text-sm tracking-[0.2em] text-[#b3261e]' : 'text-sm leading-relaxed text-[#d9d4c7]/85'}>
            {s.objective}
          </p>
        </div>
      )}

      {playing && s.hint && (
        <p className="absolute bottom-6 left-1/2 w-[90%] -translate-x-1/2 text-center text-[11px] uppercase tracking-[0.25em] text-[#d9d4c7]/50">
          {s.hint}
        </p>
      )}

      {s.prompt && playing && (
        <p className="absolute left-1/2 top-[57%] -translate-x-1/2 rounded-sm bg-black/50 px-3 py-1.5 text-xs uppercase tracking-[0.2em] text-[#d9d4c7]/90">
          {s.prompt}
        </p>
      )}

      {s.subtitle && (
        <div className="absolute bottom-[12%] left-1/2 w-[92%] max-w-2xl -translate-x-1/2 text-center" role="status" aria-live="polite">
          {s.subtitle.speaker && (
            <p className="mb-1 text-[10px] uppercase tracking-[0.35em] text-[#d9d4c7]/45">{s.subtitle.speaker}</p>
          )}
          <p
            className={
              s.subtitle.whisper
                ? 'font-serif text-xl italic tracking-wide text-[#cfc9ba]/75 md:text-2xl'
                : 'font-serif text-xl text-[#ece6d6] md:text-2xl'
            }
            style={{ textShadow: '0 1px 12px rgba(0,0,0,0.9)' }}
          >
            {s.subtitle.text}
          </p>
          {s.subtitle.translation && (
            <p className="mt-1 font-serif text-sm italic text-[#d9d4c7]/50">{s.subtitle.translation}</p>
          )}
        </div>
      )}

      {s.cameraMode && <CameraOverlay clock={s.clock} selfie={s.selfie} />}

      {s.phone && (
        <div className="absolute right-6 top-6 w-60 rounded-2xl border border-white/10 bg-black/75 p-4 backdrop-blur md:right-10 md:top-9">
          <p className="text-[10px] uppercase tracking-[0.3em] text-[#d9d4c7]/50">
            {s.phone.state === 'ringing' ? 'Incoming call' : s.phone.state === 'active' ? 'On call' : 'Call ended'}
          </p>
          <p className="mt-1 text-lg tracking-[0.2em]">{s.phone.caller}</p>
          {s.phone.state === 'ringing' && <p className="mt-2 text-xs text-[#d9d4c7]/60">Press E to answer</p>}
          {s.phone.state === 'active' && <p className="mt-2 text-xs text-[#d9d4c7]/60">Connected · no sound</p>}
        </div>
      )}

      {s.notification && (
        <div className="notif-in absolute left-1/2 top-6 w-72 -translate-x-1/2 rounded-2xl border border-white/10 bg-black/80 px-4 py-3 backdrop-blur">
          <p className="text-[10px] uppercase tracking-[0.3em] text-[#d9d4c7]/50">Gallery · now</p>
          <p className="mt-1 text-sm tracking-[0.15em]">{s.notification}</p>
          <p className="mt-1 text-[11px] text-[#d9d4c7]/50">Press E to open</p>
        </div>
      )}

      {s.photo && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/70">
          <figure className="w-[min(86vw,560px)] rounded-[28px] border border-white/10 bg-[#0b0b0b] p-3">
            <img src={s.photo || '/placeholder.svg'} alt="A photograph of you, taken from behind" className="aspect-video w-full rounded-2xl object-cover" />
            <figcaption className="px-2 pb-1 pt-3 text-xs tracking-[0.2em] text-[#d9d4c7]/60">{s.photoCaption}</figcaption>
          </figure>
        </div>
      )}

      {s.note && (
        <div className="pointer-events-auto absolute inset-0 flex items-center justify-center bg-black/60 p-6">
          <article className="max-w-md rotate-[-0.6deg] bg-[#d8d0b8] px-8 py-7 text-[#2a2418] shadow-2xl">
            <h2 className="mb-4 font-serif text-xl font-semibold">{s.note.title}</h2>
            <p className="whitespace-pre-line font-serif text-[15px] leading-relaxed">{s.note.body}</p>
            <p className="mt-6 font-mono text-[10px] uppercase tracking-[0.3em] text-[#2a2418]/50">Press E or click to close</p>
          </article>
        </div>
      )}

      <div
        aria-hidden
        className="absolute inset-0 bg-black"
        style={{ opacity: s.fade, transition: `opacity ${s.fadeMs}ms linear` }}
      />
    </div>
  )
}

function CameraOverlay({ clock, selfie }: { clock: string; selfie: boolean }) {
  return (
    <div className="absolute inset-0">
      <div className="absolute inset-4 rounded-[28px] border border-white/15 md:inset-8" />
      {(['left-8 top-8 border-l border-t', 'right-8 top-8 border-r border-t', 'left-8 bottom-8 border-l border-b', 'right-8 bottom-8 border-r border-b'] as const).map((c) => (
        <div key={c} className={`absolute h-10 w-10 border-white/60 md:h-14 md:w-14 ${c}`} />
      ))}
      <div className="absolute left-1/2 top-10 flex -translate-x-1/2 items-center gap-2 text-xs tracking-[0.25em] md:top-14">
        <span className="rec-dot h-2 w-2 rounded-full bg-[#d0281e]" />
        <span>REC</span>
        <span className="text-white/50">{clock} AM</span>
      </div>
      <p className="absolute bottom-10 left-1/2 -translate-x-1/2 text-[10px] uppercase tracking-[0.35em] text-white/60 md:bottom-14">
        {selfie ? 'Front camera' : 'Night mode · 1x'}
      </p>
      <div className="absolute left-1/2 top-1/2 h-16 w-16 -translate-x-1/2 -translate-y-1/2 border border-white/25" />
    </div>
  )
}
