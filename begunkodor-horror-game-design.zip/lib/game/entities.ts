import * as THREE from 'three'
import { radialAlpha } from './textures'

export const LAYER = {
  DEFAULT: 0,
  AVATAR: 1,
  REFLECT_ONLY: 2,
  CAMERA_ONLY: 3,
  CCTV_ONLY: 4,
} as const

export function setLayer(obj: THREE.Object3D, layer: number) {
  obj.traverse((o) => o.layers.set(layer))
}

let faceTex: THREE.Texture | null = null
let faceAlpha: THREE.Texture | null = null

function getFaceTex() {
  if (!faceTex) {
    faceTex = new THREE.TextureLoader().load('/images/girl-face.png')
    faceTex.colorSpace = THREE.SRGBColorSpace
    faceTex.offset.set(0.2, 0.3)
    faceTex.repeat.set(0.6, 0.55)
    faceAlpha = radialAlpha()
  }
  return { faceTex, faceAlpha: faceAlpha! }
}

export type Girl = THREE.Group & {
  userData: {
    frontHair: THREE.Object3D
    face: THREE.Mesh
    setFace: (v: boolean) => void
  }
}

export function makeGirl(layer: number = LAYER.DEFAULT): Girl {
  const g = new THREE.Group() as Girl
  const dressMat = new THREE.MeshStandardMaterial({ color: 0x8e8a80, roughness: 1 })
  const skinMat = new THREE.MeshStandardMaterial({ color: 0x8f8a80, roughness: 0.75 })
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x020202, roughness: 0.7, metalness: 0 })

  const profile = [
    [0.26, 0],
    [0.24, 0.25],
    [0.2, 0.6],
    [0.165, 0.95],
    [0.14, 1.12],
    [0.16, 1.3],
    [0.15, 1.4],
    [0.07, 1.46],
  ].map(([r, y]) => new THREE.Vector2(r, y))
  const dress = new THREE.Mesh(new THREE.LatheGeometry(profile, 18), dressMat)
  g.add(dress)

  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.024, 0.66, 6), skinMat)
    arm.position.set(s * 0.175, 1.06, 0.01)
    arm.rotation.z = s * 0.05
    g.add(arm)
    const hand = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.12, 0.025), skinMat)
    hand.position.set(s * 0.19, 0.68, 0.01)
    g.add(hand)
    const foot = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.03, 0.17), skinMat)
    foot.position.set(s * 0.08, 0.015, 0.06)
    g.add(foot)
  }
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.045, 0.12, 8), skinMat)
  neck.position.y = 1.48
  g.add(neck)
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.1, 16, 12), skinMat)
  head.scale.set(0.9, 1.15, 0.95)
  head.position.y = 1.6
  g.add(head)

  const backHair = new THREE.Mesh(new THREE.SphereGeometry(0.115, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.62), hairMat)
  backHair.scale.set(1, 1.15, 1.05)
  backHair.position.set(0, 1.61, -0.01)
  g.add(backHair)
  const longBack = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.8, 0.05), hairMat)
  longBack.position.set(0, 1.28, -0.09)
  g.add(longBack)
  for (const s of [-1, 1]) {
    const side = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.6, 0.12), hairMat)
    side.position.set(s * 0.105, 1.38, 0.0)
    g.add(side)
  }
  const frontHair = new THREE.Group()
  for (let i = 0; i < 7; i++) {
    const strand = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.5 + Math.random() * 0.2, 0.02), hairMat)
    strand.position.set(-0.09 + i * 0.03, 1.42 - Math.random() * 0.05, 0.1 + Math.sin(i) * 0.005)
    strand.rotation.z = (Math.random() - 0.5) * 0.08
    frontHair.add(strand)
  }
  const fringe = new THREE.Mesh(new THREE.BoxGeometry(0.21, 0.12, 0.03), hairMat)
  fringe.position.set(0, 1.68, 0.085)
  frontHair.add(fringe)
  g.add(frontHair)

  const { faceTex, faceAlpha } = getFaceTex()
  const faceMat = new THREE.MeshStandardMaterial({
    map: faceTex,
    alphaMap: faceAlpha,
    transparent: true,
    emissive: 0xffffff,
    emissiveMap: faceTex,
    emissiveIntensity: 0.07,
    roughness: 0.4,
    depthWrite: false,
  })
  const face = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.42), faceMat)
  face.position.set(0, 1.56, 0.105)
  face.visible = false
  g.add(face)

  g.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) {
      o.castShadow = true
      o.receiveShadow = true
    }
  })
  setLayer(g, layer)
  g.userData = {
    frontHair,
    face,
    setFace: (v: boolean) => {
      face.visible = v
      frontHair.visible = !v
    },
  }
  g.visible = false
  return g
}

export type Avatar = THREE.Group & { userData: { legs: THREE.Object3D[]; arms: THREE.Object3D[] } }

export function makeAvatar(layer: number = LAYER.AVATAR): Avatar {
  const g = new THREE.Group() as Avatar
  const jeans = new THREE.MeshStandardMaterial({ color: 0x1d2433, roughness: 0.9 })
  const jacket = new THREE.MeshStandardMaterial({ color: 0x2b2a26, roughness: 0.8 })
  const skin = new THREE.MeshStandardMaterial({ color: 0x7a5641, roughness: 0.7 })
  const hair = new THREE.MeshStandardMaterial({ color: 0x0b0b0b, roughness: 0.6 })
  const bag = new THREE.MeshStandardMaterial({ color: 0x3b2f22, roughness: 0.9 })
  const legs: THREE.Object3D[] = []
  const arms: THREE.Object3D[] = []
  for (const s of [-1, 1]) {
    const pivot = new THREE.Group()
    pivot.position.set(s * 0.1, 0.9, 0)
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.88, 0.16), jeans)
    leg.position.y = -0.45
    pivot.add(leg)
    const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 0.26), hair)
    shoe.position.set(0, -0.86, 0.04)
    pivot.add(shoe)
    g.add(pivot)
    legs.push(pivot)
    const ap = new THREE.Group()
    ap.position.set(s * 0.26, 1.42, 0)
    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.62, 0.12), jacket)
    arm.position.y = -0.3
    ap.add(arm)
    const hand = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.1, 0.08), skin)
    hand.position.y = -0.65
    ap.add(hand)
    g.add(ap)
    arms.push(ap)
  }
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.62, 0.26), jacket)
  torso.position.y = 1.18
  g.add(torso)
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.1, 8), skin)
  neck.position.y = 1.53
  g.add(neck)
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.11, 16, 12), skin)
  head.scale.set(0.92, 1.1, 1)
  head.position.y = 1.65
  g.add(head)
  const hairCap = new THREE.Mesh(new THREE.SphereGeometry(0.117, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.5), hair)
  hairCap.position.set(0, 1.67, -0.01)
  g.add(hairCap)
  const pack = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.44, 0.16), bag)
  pack.position.set(0, 1.15, -0.21)
  g.add(pack)
  g.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) o.castShadow = true
  })
  setLayer(g, layer)
  g.userData = { legs, arms }
  return g
}

export function animateAvatar(a: Avatar, phase: number, amount: number) {
  const s = Math.sin(phase) * 0.5 * amount
  a.userData.legs[0].rotation.x = s
  a.userData.legs[1].rotation.x = -s
  a.userData.arms[0].rotation.x = -s * 0.8
  a.userData.arms[1].rotation.x = s * 0.8
}

export type Train = THREE.Group & { userData: { girl: Girl; length: number; headlight: THREE.PointLight } }

export function makeTrain(): Train {
  const g = new THREE.Group() as Train
  const coachLen = 20
  const coaches = 6
  const body = new THREE.MeshStandardMaterial({ color: 0x4a1e1a, roughness: 0.7, metalness: 0.2 })
  const stripe = new THREE.MeshStandardMaterial({ color: 0xb59a52, roughness: 0.6 })
  const under = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 })
  const winMat = new THREE.MeshStandardMaterial({
    color: 0x2a2416,
    emissive: 0xc9a865,
    emissiveIntensity: 0.55,
    roughness: 0.2,
  })
  const barMat = new THREE.MeshStandardMaterial({ color: 0x0c0c0c })
  const sideX = -1.6

  for (let i = 0; i < coaches; i++) {
    const cz = i * (coachLen + 0.6) + coachLen / 2
    const c = new THREE.Mesh(new THREE.BoxGeometry(3.2, 3.8, coachLen), body)
    c.position.set(0, 1.3, cz)
    g.add(c)
    const s = new THREE.Mesh(new THREE.BoxGeometry(3.24, 0.18, coachLen), stripe)
    s.position.set(0, 0.6, cz)
    g.add(s)
    const u = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.7, coachLen - 2), under)
    u.position.set(0, -0.85, cz)
    g.add(u)
    if (i === 0) continue
    for (let w = 0; w < 8; w++) {
      const wz = cz - coachLen / 2 + 2 + w * 2.3
      const win = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.9), winMat)
      win.position.set(sideX - 0.01, 1.45, wz)
      win.rotation.y = -Math.PI / 2
      g.add(win)
      for (let b = 0; b < 4; b++) {
        const bar = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.9, 0.025), barMat)
        bar.position.set(sideX - 0.03, 1.45, wz - 0.45 + b * 0.3)
        g.add(bar)
      }
    }
  }
  const nose = new THREE.Mesh(new THREE.BoxGeometry(3.2, 2.6, 1.5), body)
  nose.position.set(0, 0.7, -0.7)
  g.add(nose)
  const headlight = new THREE.PointLight(0xfff1c4, 0, 40, 1.6)
  headlight.position.set(0, 2.4, -2)
  g.add(headlight)
  const lamp = new THREE.Mesh(
    new THREE.CircleGeometry(0.22, 16),
    new THREE.MeshBasicMaterial({ color: 0xfff6d8 }),
  )
  lamp.position.set(0, 2.6, -1.46)
  lamp.rotation.y = Math.PI
  g.add(lamp)

  const girl = makeGirl()
  const last = coaches - 1
  const wz = last * (coachLen + 0.6) + 2 + 6 * 2.3
  girl.position.set(sideX - 0.06, -0.1, wz)
  girl.rotation.y = -Math.PI / 2
  g.add(girl)
  const sill = new THREE.Mesh(new THREE.BoxGeometry(0.04, 1.3, 1.3), body)
  sill.position.set(sideX - 0.38, 0.35, wz)
  g.add(sill)
  const lintel = new THREE.Mesh(new THREE.BoxGeometry(0.04, 1.4, 1.3), body)
  lintel.position.set(sideX - 0.38, 2.62, wz)
  g.add(lintel)

  g.traverse((o) => {
    if ((o as THREE.Mesh).isMesh) o.receiveShadow = true
  })
  g.userData = { girl, length: coaches * (coachLen + 0.6), headlight }
  g.visible = false
  return g
}
