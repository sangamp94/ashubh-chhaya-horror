import { HorrorGame } from '@/components/game/horror-game'

export default function Page() {
  return <HorrorGame />
}
