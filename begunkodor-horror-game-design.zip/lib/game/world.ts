import * as THREE from 'three'
import { Reflector } from 'three/examples/jsm/objects/Reflector.js'
import {
  clockCanvas,
  concreteTexture,
  edgeTexture,
  gravelTexture,
  paperTexture,
  signTexture,
  textLabel,
  tileTexture,
  wallTexture,
} from './textures'

export type Collider = {
  minX: number
  maxX: number
  minZ: number
  maxZ: number
  minY: number
  maxY: number
  enabled: boolean
}

export type Lamp = {
  light: THREE.PointLight
  tube: THREE.Mesh
  base: number
  on: boolean
  flicker: number
  broken: boolean
}

export type Door = {
  pivot: THREE.Group
  collider: Collider
  angle: number
  target: number
  speed: number
  locked: boolean
  center: THREE.Vector3
  openAngle: number
}

export type Region = 'platform' | 'hall' | 'office' | 'cctv' | 'copy' | 'bridge' | 'stairs' | 'street' | 'tracks'

const DOOR_H = 2.3

function scaleUV(geo: THREE.BufferGeometry, w: number, h: number, d: number, unit: number, vFull = false) {
  const uv = geo.attributes.uv as THREE.BufferAttribute
  const dims: [number, number][] = [
    [d, h],
    [d, h],
    [w, d],
    [w, d],
    [w, h],
    [w, h],
  ]
  for (let f = 0; f < 6; f++) {
    const [du, dv] = dims[f]
    for (let i = 0; i < 4; i++) {
      const idx = f * 4 + i
      uv.setXY(idx, uv.getX(idx) * (du / unit), vFull && f !== 2 && f !== 3 ? uv.getY(idx) : uv.getY(idx) * (dv / unit))
    }
  }
  uv.needsUpdate = true
}

export class World {
  scene: THREE.Scene
  colliders: Collider[] = []
  staticMeshes: THREE.Mesh[] = []
  lamps: Record<string, Lamp> = {}
  doors: Record<string, Door> = {}
  mats: Record<string, THREE.Material> = {}
  clock = { tex: null as THREE.Texture | null, draw: (_h: number, _m: number) => {} }
  copyClock = { tex: null as THREE.Texture | null, draw: (_h: number, _m: number) => {} }
  mirror!: Reflector
  cctvScreen!: THREE.Mesh
  cctvMaterial!: THREE.ShaderMaterial
  cctvStamp!: { tex: THREE.Texture; draw: (t: string) => void }
  cctvCamMesh!: THREE.Group
  drawer!: THREE.Mesh
  officeKey!: THREE.Mesh
  gateKey!: THREE.Mesh
  hiddenPatch!: { mesh: THREE.Mesh; collider: Collider }
  photoFrame!: THREE.Mesh
  photoDate!: { tex: THREE.Texture; draw: (t: string) => void }
  evidence: Record<string, THREE.Object3D> = {}
  fan!: THREE.Object3D
  copyFan!: THREE.Object3D
  rain!: THREE.LineSegments
  private rainVel!: Float32Array
  hemi!: THREE.HemisphereLight
  street!: THREE.Group
  exitDoor!: Door

  constructor(scene: THREE.Scene) {
    this.scene = scene
  }

  // ---------- helpers ----------
  box(
    w: number,
    h: number,
    d: number,
    mat: THREE.Material,
    x: number,
    y: number,
    z: number,
    opts: { collide?: boolean; unit?: number; vFull?: boolean; cast?: boolean; parent?: THREE.Object3D } = {},
  ) {
    const geo = new THREE.BoxGeometry(w, h, d)
    if (opts.unit) scaleUV(geo, w, h, d, opts.unit, opts.vFull)
    const m = new THREE.Mesh(geo, mat)
    m.position.set(x, y, z)
    m.receiveShadow = true
    m.castShadow = opts.cast ?? false
    ;(opts.parent ?? this.scene).add(m)
    this.staticMeshes.push(m)
    if (opts.collide) this.addCollider(x - w / 2, x + w / 2, z - d / 2, z + d / 2, y - h / 2, y + h / 2)
    return m
  }

  addCollider(minX: number, maxX: number, minZ: number, maxZ: number, minY = -50, maxY = 50) {
    const c: Collider = { minX, maxX, minZ, maxZ, minY, maxY, enabled: true }
    this.colliders.push(c)
    return c
  }

  wallZ(x: number, z1: number, z2: number, h: number, gaps: [number, number][] = [], t = 0.3, y0 = 0, mat = this.mats.wall) {
    let cur = z1
    const sorted = [...gaps].sort((a, b) => a[0] - b[0])
    for (const [g1, g2] of sorted) {
      if (g1 > cur) this.box(t, h, g1 - cur, mat, x, y0 + h / 2, (cur + g1) / 2, { collide: true, unit: 3, vFull: true })
      const lh = h - DOOR_H
      if (lh > 0) this.box(t, lh, g2 - g1, mat, x, y0 + DOOR_H + lh / 2, (g1 + g2) / 2, { unit: 3 })
      cur = g2
    }
    if (z2 > cur) this.box(t, h, z2 - cur, mat, x, y0 + h / 2, (cur + z2) / 2, { collide: true, unit: 3, vFull: true })
  }

  wallX(z: number, x1: number, x2: number, h: number, gaps: [number, number][] = [], t = 0.3, y0 = 0, mat = this.mats.wall) {
    let cur = x1
    const sorted = [...gaps].sort((a, b) => a[0] - b[0])
    for (const [g1, g2] of sorted) {
      if (g1 > cur) this.box(g1 - cur, h, t, mat, (cur + g1) / 2, y0 + h / 2, z, { collide: true, unit: 3, vFull: true })
      const lh = h - DOOR_H
      if (lh > 0) this.box(g2 - g1, lh, t, mat, (g1 + g2) / 2, y0 + DOOR_H + lh / 2, z, { unit: 3 })
      cur = g2
    }
    if (x2 > cur) this.box(x2 - cur, h, t, mat, (cur + x2) / 2, y0 + h / 2, z, { collide: true, unit: 3, vFull: true })
  }

  lamp(key: string, x: number, y: number, z: number, color: number, intensity: number, distance: number, tubeLen = 1.2, alongX = false) {
    const light = new THREE.PointLight(color, intensity, distance, 1.7)
    light.position.set(x, y - 0.15, z)
    this.scene.add(light)
    const tubeMat = new THREE.MeshStandardMaterial({ color: 0x222222, emissive: color, emissiveIntensity: 2.2 })
    const tube = new THREE.Mesh(new THREE.BoxGeometry(alongX ? tubeLen : 0.07, 0.06, alongX ? 0.07 : tubeLen), tubeMat)
    tube.position.set(x, y, z)
    this.scene.add(tube)
    const housing = new THREE.Mesh(new THREE.BoxGeometry(alongX ? tubeLen + 0.1 : 0.16, 0.05, alongX ? 0.16 : tubeLen + 0.1), this.mats.metal)
    housing.position.set(x, y + 0.06, z)
    this.scene.add(housing)
    this.lamps[key] = { light, tube, base: intensity, on: true, flicker: 0, broken: false }
    return this.lamps[key]
  }

  setLamp(key: string, on: boolean) {
    const l = this.lamps[key]
    if (l) l.on = on
  }

  makeDoor(key: string, hingeX: number, hingeZ: number, width: number, openAngle: number, alongZ: boolean, color = 0x3a2a1c) {
    const pivot = new THREE.Group()
    pivot.position.set(hingeX, 0, hingeZ)
    const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.8 })
    const panel = new THREE.Mesh(new THREE.BoxGeometry(alongZ ? 0.06 : width, DOOR_H - 0.02, alongZ ? width : 0.06), mat)
    panel.position.set(alongZ ? 0 : width / 2, DOOR_H / 2, alongZ ? width / 2 : 0)
    panel.castShadow = true
    panel.receiveShadow = true
    pivot.add(panel)
    const knob = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 6), this.mats.brass)
    knob.position.set(alongZ ? 0.06 : width - 0.1, 1.05, alongZ ? width - 0.1 : 0.06)
    pivot.add(knob)
    const knob2 = knob.clone()
    knob2.position.set(alongZ ? -0.06 : width - 0.1, 1.05, alongZ ? width - 0.1 : -0.06)
    pivot.add(knob2)
    this.scene.add(pivot)
    const collider = alongZ
      ? this.addCollider(hingeX - 0.12, hingeX + 0.12, hingeZ, hingeZ + width, -1, DOOR_H + 1)
      : this.addCollider(hingeX, hingeX + width, hingeZ - 0.12, hingeZ + 0.12, -1, DOOR_H + 1)
    const center = alongZ ? new THREE.Vector3(hingeX, 1.2, hingeZ + width / 2) : new THREE.Vector3(hingeX + width / 2, 1.2, hingeZ)
    const door: Door = { pivot, collider, angle: 0, target: 0, speed: 1.6, locked: true, center, openAngle }
    this.doors[key] = door
    return door
  }

  openDoor(key: string, speed = 1.6, fraction = 1) {
    const d = this.doors[key]
    d.target = d.openAngle * fraction
    d.speed = speed
  }

  closeDoor(key: string, speed = 6) {
    const d = this.doors[key]
    d.target = 0
    d.speed = speed
  }

  // ---------- build ----------
  build() {
    const s = this.scene
    const concrete = concreteTexture()
    const wall = wallTexture()
    const tile = tileTexture()
    const gravel = gravelTexture()
    const edge = edgeTexture()
    this.mats = {
      concrete: new THREE.MeshStandardMaterial({ map: concrete, roughness: 0.42, metalness: 0.05, color: 0x9a9890 }),
      ceiling: new THREE.MeshStandardMaterial({ map: concrete, roughness: 0.95, color: 0x55534d }),
      wall: new THREE.MeshStandardMaterial({ map: wall, roughness: 0.9 }),
      tile: new THREE.MeshStandardMaterial({ map: tile, roughness: 0.35 }),
      gravel: new THREE.MeshStandardMaterial({ map: gravel, roughness: 1 }),
      edge: new THREE.MeshStandardMaterial({ map: edge, roughness: 0.6 }),
      metal: new THREE.MeshStandardMaterial({ color: 0x23272a, roughness: 0.6, metalness: 0.6 }),
      rust: new THREE.MeshStandardMaterial({ color: 0x3d2a1e, roughness: 0.85, metalness: 0.3 }),
      rail: new THREE.MeshStandardMaterial({ color: 0x5c5f63, roughness: 0.3, metalness: 0.9 }),
      wood: new THREE.MeshStandardMaterial({ color: 0x4a3322, roughness: 0.8 }),
      brass: new THREE.MeshStandardMaterial({ color: 0xb08a3a, roughness: 0.3, metalness: 0.9 }),
      brick: new THREE.MeshStandardMaterial({ color: 0x3a2622, roughness: 1, map: concrete }),
      asphalt: new THREE.MeshStandardMaterial({ color: 0x2a2a2c, roughness: 0.5, map: gravel }),
      foliage: new THREE.MeshStandardMaterial({ color: 0x0d140f, roughness: 1 }),
      steelGreen: new THREE.MeshStandardMaterial({ color: 0x1f3a2c, roughness: 0.7, metalness: 0.4 }),
    }
    const m = this.mats

    this.hemi = new THREE.HemisphereLight(0x223040, 0x080806, 0.35)
    s.add(this.hemi)

    // ---- platform ----
    this.box(8, 1.2, 90, m.concrete, 0, -0.6, -15, { unit: 4 })
    this.box(0.6, 0.02, 90, m.edge, 3.7, 0.011, -15, { unit: 2 })
    this.addCollider(4, 4.4, -70, 40) // platform edge
    this.addCollider(-4.5, 4.4, 30, 30.4) // north end
    this.wallX(30.2, -4, 4, 1.1, [], 0.1, 0, m.metal)
    this.addCollider(-4.5, 4.4, -60.4, -60, -50, 4) // south end at ground
    this.box(8, 1.1, 0.1, m.metal, 0, 0.55, -60.2)
    // canopy
    this.box(9, 0.15, 90, m.ceiling, 0.3, 4.65, -15, { unit: 4 })
    for (let z = 25; z >= -55; z -= 10) {
      this.box(0.22, 4.6, 0.22, m.steelGreen, 2.7, 2.3, z, { collide: true, cast: true })
      this.box(0.15, 0.15, 7, m.steelGreen, 2.7, 4.5, z)
    }
    this.lamp('p0', 0.4, 4.4, 22, 0xd6ecff, 9, 18)
    this.lamp('p1', 0.4, 4.4, 4, 0xd6ecff, 9, 18)
    this.lamp('p2', 0.4, 4.4, -14, 0xd6ecff, 8, 18)
    this.lamp('p3', 0.4, 4.4, -32, 0xd6ecff, 7, 16)
    this.lamp('p4', 0.4, 4.4, -50, 0xd6ecff, 7, 16)
    this.lamps.p3.broken = true

    // signs
    const sign = new THREE.MeshStandardMaterial({ map: signTexture(['बेगुनकोडोर', 'BEGUNKODOR']), roughness: 0.6 })
    for (const z of [12, -26]) {
      const sm = new THREE.Mesh(new THREE.PlaneGeometry(3, 0.75), sign)
      sm.position.set(-3.83, 3.1, z)
      sm.rotation.y = Math.PI / 2
      s.add(sm)
    }
    const hang = new THREE.MeshStandardMaterial({ map: signTexture(['प्लेटफॉर्म 1', 'PLATFORM 1'], '#1d3557', '#e8e8e8'), roughness: 0.6 })
    const hs = new THREE.Mesh(new THREE.BoxGeometry(2, 0.5, 0.05), [m.metal, m.metal, m.metal, m.metal, hang, hang])
    hs.position.set(0, 3.7, -8)
    s.add(hs)

    // benches
    for (const z of [7, -9, -24, -44]) {
      this.box(2.4, 0.08, 0.5, m.concrete, -3.4, 0.45, z, { collide: true })
      this.box(0.1, 0.45, 0.4, m.concrete, -3.4 - 1, 0.22, z)
      this.box(0.1, 0.45, 0.4, m.concrete, -3.4 + 1, 0.22, z)
    }
    // dustbin, water tap
    this.box(0.4, 0.8, 0.4, m.rust, -3.6, 0.4, -4, { collide: true, cast: true })
    this.box(0.5, 0.9, 0.3, m.steelGreen, -3.7, 0.45, -36, { collide: true, cast: true })

    // platform clock
    const pc = clockCanvas()
    this.clock = pc
    const clockMat = new THREE.MeshStandardMaterial({ map: pc.tex, roughness: 0.5, emissive: 0x222222, emissiveMap: pc.tex })
    const pClock = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.08, 24), [m.metal, clockMat, clockMat])
    pClock.rotation.z = Math.PI / 2
    pClock.position.set(0.4, 3.9, 13)
    s.add(pClock)

    // tracks
    this.box(9.6, 0.1, 260, m.gravel, 8.8, -1.25, 10, { unit: 4 })
    for (const x of [5.75, 7.25]) this.box(0.08, 0.14, 260, m.rail, x, -1.13, 10)
    const sleeperGeo = new THREE.BoxGeometry(2.4, 0.08, 0.22)
    const sleepers = new THREE.InstancedMesh(sleeperGeo, m.wood, 360)
    const dummy = new THREE.Object3D()
    for (let i = 0; i < 360; i++) {
      dummy.position.set(6.5, -1.18, -120 + i * 0.72)
      dummy.updateMatrix()
      sleepers.setMatrixAt(i, dummy.matrix)
    }
    sleepers.receiveShadow = true
    s.add(sleepers)
    this.box(0.4, 3, 260, m.brick, 13.6, 0.2, 10)
    // trees beyond
    for (let i = 0; i < 26; i++) {
      const tz = -110 + i * 9 + Math.random() * 4
      const tr = new THREE.Mesh(new THREE.ConeGeometry(2 + Math.random() * 1.5, 7 + Math.random() * 4, 6), m.foliage)
      tr.position.set(17 + Math.random() * 6, 3, tz)
      s.add(tr)
    }

    // ---- building wall ----
    const gaps: [number, number][] = [
      [16, 20],
      [-1.6, -0.4],
      [-19.6, -18.4],
      [-40.6, -39.4],
    ]
    this.wallZ(-4.15, -60, 30, 4.6, gaps)
    // hidden door patch (wall fills gap until the door "appears")
    const patch = this.box(0.3, DOOR_H, 1.2, m.wall, -4.15, DOOR_H / 2, -40, { unit: 3, vFull: true })
    const pc2 = this.addCollider(-4.3, -4, -40.6, -39.4, -1, 3)
    this.hiddenPatch = { mesh: patch, collider: pc2 }
    const hidden = this.makeDoor('hidden', -4.15, -40.6, 1.2, -1.5, true, 0x2a1d14)
    hidden.angle = -0.95
    hidden.target = -0.95
    hidden.pivot.rotation.y = -0.95
    hidden.pivot.visible = false

    // ---- rooms ----
    this.buildHall(18, false)
    this.buildHall(-40, true)
    this.buildOffice()
    this.buildCctv()
    this.buildBridge()
    this.buildStreet()
    this.buildRain()
  }

  buildHall(zc: number, isCopy: boolean) {
    const m = this.mats
    const x1 = -16
    const x2 = -4.3
    const h = 4.2
    this.box(x2 - x1, 0.1, 12, m.tile, (x1 + x2) / 2, -0.05, zc, { unit: 3 })
    this.box(x2 - x1, 0.12, 12, m.ceiling, (x1 + x2) / 2, h, zc, { unit: 4 })
    this.wallX(zc + 6, x1, x2, h)
    this.wallX(zc - 6, x1, x2, h)
    this.wallZ(x1, zc - 6, zc + 6, h, [[zc - 1, zc + 1]])
    // exit gate
    const door = this.makeDoor(isCopy ? 'copyExit' : 'exit', x1, zc - 1, 2, -1.3, true, 0x1c2a22)
    if (!isCopy) this.exitDoor = door
    // ticket counter
    this.box(4, 1.1, 0.8, m.wood, -10, 0.55, zc + 5.4, { collide: true })
    this.box(4, 2.9, 0.1, m.wall, -10, 2.75, zc + 5.4, { unit: 3 })
    const counterSign = new THREE.MeshStandardMaterial({ map: signTexture(['टिकट घर', 'BOOKING OFFICE'], '#7a1d1d', '#f1e6c8') })
    const cs = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.6), counterSign)
    cs.position.set(-10, 3.4, zc + 5.33)
    cs.rotation.y = Math.PI
    this.scene.add(cs)
    // benches
    for (const x of [-13, -8]) {
      this.box(2.4, 0.08, 0.5, m.wood, x, 0.45, zc - 5.4, { collide: true })
      this.box(2.4, 0.5, 0.06, m.wood, x, 0.75, zc - 5.65)
    }
    // clock
    const cl = clockCanvas()
    const clMat = new THREE.MeshStandardMaterial({ map: cl.tex, emissive: 0x1a1a1a, emissiveMap: cl.tex })
    const clock = new THREE.Mesh(new THREE.CircleGeometry(0.4, 24), clMat)
    clock.position.set(-6, 3.2, zc + 5.84)
    clock.rotation.y = Math.PI
    this.scene.add(clock)
    if (isCopy) {
      this.copyClock = cl
      cl.draw(2, 14)
    } else {
      cl.draw(2, 14)
      const prev = this.clock.draw
      this.clock = { tex: this.clock.tex, draw: (hh, mm) => { prev(hh, mm); cl.draw(hh, mm) } }
    }
    // ceiling fan
    const fan = new THREE.Group()
    fan.position.set(-10, h - 0.5, zc)
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.12, 12), m.metal)
    fan.add(hub)
    for (let i = 0; i < 3; i++) {
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.02, 0.14), m.metal)
      blade.position.x = 0.5
      const bp = new THREE.Group()
      bp.rotation.y = (i / 3) * Math.PI * 2
      bp.add(blade)
      fan.add(bp)
    }
    const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.5), m.metal)
    rod.position.set(-10, h - 0.25, zc)
    this.scene.add(rod)
    this.scene.add(fan)
    if (isCopy) this.copyFan = fan
    else this.fan = fan

    this.lamp(isCopy ? 'copy' : 'hall', -7, h - 0.05, zc, isCopy ? 0xe8d9b0 : 0xe8d9b0, 6, 14, 1.2, true)

    // notice board
    const notice = new THREE.MeshStandardMaterial({
      map: paperTexture('सूचना / NOTICE', ['Last train to Purulia: 01:52', 'Station closes after last train.', 'Do not wait on platform', 'after midnight.', '', '— Station Master']),
    })
    const nb = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.2), notice)
    nb.position.set(-15.84, 1.8, zc + 3.5)
    nb.rotation.y = Math.PI / 2
    this.scene.add(nb)

    if (isCopy) {
      // the photograph
      const frame = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.75, 0.04), m.wood)
      frame.position.set(-10, 1.75, zc - 5.82)
      this.scene.add(frame)
      this.photoFrame = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.65), new THREE.MeshBasicMaterial({ color: 0x111111 }))
      this.photoFrame.position.set(-10, 1.75, zc - 5.79)
      this.scene.add(this.photoFrame)
      this.photoDate = textLabel('', 512, 64, '#ff8a3d', 'bold 40px monospace')
      const dl = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.11), new THREE.MeshBasicMaterial({ map: this.photoDate.tex, transparent: true }))
      dl.position.set(-10, 1.3, zc - 5.79)
      this.scene.add(dl)

      // evidence
      const diary = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.04, 0.3), new THREE.MeshStandardMaterial({ color: 0x5a1a14, roughness: 0.8 }))
      diary.position.set(-13, 0.51, zc - 5.35)
      diary.rotation.y = 0.3
      this.scene.add(diary)
      this.evidence.diary = diary
      const ticket = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.08), new THREE.MeshStandardMaterial({ color: 0xd8c9a0, side: THREE.DoubleSide }))
      ticket.rotation.x = -Math.PI / 2
      ticket.position.set(-10.6, 1.11, zc + 5.2)
      this.scene.add(ticket)
      this.evidence.ticket = ticket
      const phone = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.012, 0.16), new THREE.MeshStandardMaterial({ color: 0x0a0a0a, emissive: 0x335577, emissiveIntensity: 0.6 }))
      phone.position.set(-8, 0.5, zc - 5.35)
      this.scene.add(phone)
      this.evidence.recording = phone
    }
  }

  buildOffice() {
    const m = this.mats
    const x1 = -12
    const x2 = -4.3
    const z1 = -6
    const z2 = 4
    const h = 3.4
    this.box(x2 - x1, 0.1, z2 - z1, m.tile, (x1 + x2) / 2, -0.05, (z1 + z2) / 2, { unit: 3 })
    this.box(x2 - x1, 0.12, z2 - z1, m.ceiling, (x1 + x2) / 2, h, (z1 + z2) / 2, { unit: 4 })
    this.wallX(z2, x1, x2, h)
    this.wallX(z1, x1, x2, h)
    this.wallZ(x1, z1, z2, h)
    const door = this.makeDoor('office', -4.15, -1.6, 1.2, -1.5, true)
    door.locked = false
    door.angle = door.target = -1.25
    door.pivot.rotation.y = -1.25
    // desk
    this.box(1.0, 0.06, 2.0, m.wood, -11.4, 0.78, -0.5, { collide: true, cast: true })
    this.box(0.9, 0.75, 0.05, m.wood, -11.4, 0.38, -1.45)
    this.box(0.9, 0.75, 0.05, m.wood, -11.4, 0.38, 0.45)
    this.drawer = this.box(0.6, 0.16, 0.6, m.wood, -11.3, 0.64, -0.5, { cast: true })
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.03, 0.16), m.brass)
    handle.position.set(0.31, 0, 0)
    this.drawer.add(handle)
    this.officeKey = new THREE.Mesh(new THREE.TorusGeometry(0.03, 0.008, 6, 12), m.brass)
    const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.012, 0.012), m.brass)
    shaft.position.x = 0.07
    this.officeKey.add(shaft)
    this.officeKey.rotation.x = -Math.PI / 2
    this.officeKey.position.set(0, 0.09, 0)
    this.drawer.add(this.officeKey)
    // register book, phone
    this.box(0.35, 0.05, 0.25, new THREE.MeshStandardMaterial({ color: 0x1f2c4a }), -11.3, 0.835, -1.0)
    this.box(0.2, 0.08, 0.2, m.metal, -11.5, 0.85, 0.1)
    // chair
    this.box(0.5, 0.06, 0.5, m.wood, -10.5, 0.48, -0.5, { collide: true })
    this.box(0.06, 0.6, 0.5, m.wood, -10.25, 0.8, -0.5)
    // almirah
    this.box(1.0, 2.0, 0.5, m.steelGreen, -6.2, 1.0, -5.7, { collide: true, cast: true })
    // mirror
    this.box(1.3, 1.7, 0.05, m.wood, -8, 1.6, 3.82)
    this.mirror = new Reflector(new THREE.PlaneGeometry(1.15, 1.55), {
      clipBias: 0.003,
      textureWidth: 512,
      textureHeight: 680,
      color: 0x8a8f94,
    })
    this.mirror.position.set(-8, 1.6, 3.79)
    this.mirror.rotation.y = Math.PI
    this.scene.add(this.mirror)
    this.lamp('office', -8, h - 0.05, -1, 0xfff2d6, 14, 14, 1.2, true)
    // file stacks
    for (let i = 0; i < 4; i++) this.box(0.3, 0.05, 0.4, new THREE.MeshStandardMaterial({ color: 0xc8b98a }), -6.2, 2.03 + i * 0.05, -5.7)
  }

  buildCctv() {
    const m = this.mats
    const x1 = -12
    const x2 = -4.3
    const z1 = -24
    const z2 = -14
    const h = 3.4
    this.box(x2 - x1, 0.1, z2 - z1, m.tile, (x1 + x2) / 2, -0.05, (z1 + z2) / 2, { unit: 3 })
    this.box(x2 - x1, 0.12, z2 - z1, m.ceiling, (x1 + x2) / 2, h, (z1 + z2) / 2, { unit: 4 })
    this.wallX(z2, x1, x2, h)
    this.wallX(z1, x1, x2, h)
    this.wallZ(x1, z1, z2, h)
    this.makeDoor('cctv', -4.15, -19.6, 1.2, -1.5, true, 0x2b2b2b)
    this.box(1.0, 0.06, 4, m.wood, -11.4, 0.78, -19, { collide: true })
    this.box(0.9, 0.75, 0.05, m.wood, -11.4, 0.38, -20.95)
    this.box(0.9, 0.75, 0.05, m.wood, -11.4, 0.38, -17.05)

    this.cctvStamp = textLabel('CAM 02  02:16:04', 512, 64, '#e6e6e6', 'bold 34px monospace')
    this.cctvMaterial = new THREE.ShaderMaterial({
      uniforms: {
        tDiffuse: { value: null },
        tStamp: { value: this.cctvStamp.tex },
        time: { value: 0 },
        noiseAmt: { value: 0.12 },
        power: { value: 1 },
      },
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `
        uniform sampler2D tDiffuse; uniform sampler2D tStamp; uniform float time; uniform float noiseAmt; uniform float power;
        varying vec2 vUv;
        float rnd(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233)) + time*43.0) * 43758.5453); }
        void main(){
          vec2 uv = vUv;
          uv.x += (rnd(vec2(floor(uv.y*80.0), 1.0)) - 0.5) * 0.004;
          vec3 c = texture2D(tDiffuse, uv).rgb;
          float g = dot(c, vec3(0.3,0.59,0.11));
          g = pow(g, 0.6) * 1.6;
          g += (rnd(uv*300.0) - 0.5) * noiseAmt;
          g *= 0.85 + 0.15 * sin(uv.y * 600.0);
          vec2 d = uv - 0.5; g *= 1.0 - dot(d,d)*1.4;
          vec4 st = texture2D(tStamp, vec2((uv.x - 0.02) / 0.6, (uv.y - 0.88) / 0.1));
          float inStamp = step(0.02, uv.x) * step(uv.x, 0.62) * step(0.88, uv.y) * step(uv.y, 0.98);
          g = mix(g, 1.0, st.a * inStamp);
          gl_FragColor = vec4(vec3(g*0.85, g, g*0.9) * power, 1.0);
        }`,
    })
    this.cctvScreen = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 0.75), this.cctvMaterial)
    this.cctvScreen.position.set(-11.36, 1.3, -19)
    this.cctvScreen.rotation.y = Math.PI / 2
    this.scene.add(this.cctvScreen)
    this.box(0.25, 0.85, 1.1, m.metal, -11.55, 1.3, -19)
    for (const z of [-20.4, -17.6]) {
      this.box(0.25, 0.5, 0.65, m.metal, -11.55, 1.08, z)
      const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.55, 0.4), new THREE.MeshStandardMaterial({ color: 0x0a0d0a, emissive: 0x1a2a1f, emissiveIntensity: 0.6 }))
      scr.position.set(-11.42, 1.08, z)
      scr.rotation.y = Math.PI / 2
      this.scene.add(scr)
    }
    this.lamp('cctv', -8, h - 0.05, -19, 0xbfd8c8, 3, 10, 1.2, true)

    // physical CCTV camera on platform
    const cam = new THREE.Group()
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.16, 0.36), m.metal)
    cam.add(body)
    const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.05, 10), new THREE.MeshBasicMaterial({ color: 0x050505 }))
    lens.rotation.x = Math.PI / 2
    lens.position.z = 0.2
    cam.add(lens)
    const led = new THREE.Mesh(new THREE.SphereGeometry(0.012, 6, 6), new THREE.MeshBasicMaterial({ color: 0xff2020 }))
    led.position.set(0.05, 0.05, 0.18)
    cam.add(led)
    cam.position.set(-3.75, 3.9, 6)
    cam.lookAt(-1.5, 1, 15)
    this.scene.add(cam)
    this.cctvCamMesh = cam
  }

  buildBridge() {
    const m = this.mats
    // stairs visual
    for (let i = 0; i < 20; i++) {
      const y = (i + 1) * 0.25
      this.box(3, 0.25, 0.5, m.concrete, -2, y - 0.125, -46.25 - i * 0.5, { unit: 2 })
    }
    // stair rails
    this.addCollider(-0.6, -0.4, -56, -46)
    const railGeo = new THREE.BoxGeometry(0.05, 0.05, 11.2)
    const rail = new THREE.Mesh(railGeo, m.metal)
    rail.position.set(-0.5, 3.6, -51)
    rail.rotation.x = Math.atan2(5, 10)
    this.scene.add(rail)
    this.addCollider(-3.6, -0.5, -56.1, -55.9, -50, 2.5)
    this.box(3, 4.8, 0.2, m.wall, -2, 2.4, -56.0) // wall under top of stairs

    // deck
    this.box(19.6, 0.2, 4, m.concrete, 6.3, 4.9, -58, { unit: 3 })
    this.box(19.6, 0.15, 4.4, m.rust, 6.3, 8.1, -58)
    // railings
    const railH = 1.1
    this.box(16.5, railH, 0.06, m.steelGreen, 7.75, 5 + railH / 2, -56.05)
    this.box(19.6, railH, 0.06, m.steelGreen, 6.3, 5 + railH / 2, -59.95)
    for (let x = -3.4; x <= 16; x += 1.2) {
      this.box(0.06, 3.1, 0.06, m.steelGreen, x, 6.55, -59.95)
      if (x > -0.5) this.box(0.06, 3.1, 0.06, m.steelGreen, x, 6.55, -56.05)
    }
    this.addCollider(-0.5, 16.2, -56.1, -55.9, 4, 12)
    this.addCollider(-3.6, 16.2, -60.1, -59.9, 4, 12)
    this.addCollider(16, 16.3, -60.2, -55.8, 4, 12)
    this.addCollider(-3.8, -3.5, -60.2, -55.8, 4, 12)
    this.box(0.3, 3.2, 4, m.rust, 16.15, 6.6, -58)
    // supports
    for (const x of [4.6, 9.6, 13.4]) {
      this.box(0.35, 6.2, 0.35, m.steelGreen, x, 1.8, -56.3, { cast: true })
      this.box(0.35, 6.2, 0.35, m.steelGreen, x, 1.8, -59.7, { cast: true })
    }
    // lamps
    this.lamp('b0', -1.5, 7.9, -58, 0xe0f0ff, 5, 9)
    this.lamp('b1', 3.5, 7.9, -58, 0xe0f0ff, 5, 9)
    this.lamp('b2', 8.5, 7.9, -58, 0xe0f0ff, 5, 9)
    this.lamp('b3', 14, 7.9, -58, 0xe0f0ff, 5, 9)
    // gate key spot
    this.gateKey = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.012, 6, 14), m.brass)
    for (let i = 0; i < 3; i++) {
      const k = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.015, 0.02), m.brass)
      k.position.set(0.09, 0, -0.02 + i * 0.02)
      k.rotation.y = (i - 1) * 0.5
      this.gateKey.add(k)
    }
    this.gateKey.rotation.x = -Math.PI / 2
    this.gateKey.position.set(15.3, 5.02, -57.4)
    this.gateKey.visible = false
    this.scene.add(this.gateKey)
  }

  buildStreet() {
    const m = this.mats
    const g = new THREE.Group()
    this.street = g
    this.scene.add(g)
    this.box(40, 0.1, 60, m.asphalt, -36.3, -0.05, 18, { unit: 5, parent: g })
    this.wallZ(-16.3, 3, 33, 7, [[17, 19]], 0.1)
    this.addCollider(-60, -16.3, -12.3, -12)
    this.addCollider(-60, -16.3, 48, 48.3)
    this.addCollider(-60.3, -60, -12, 48)
    // facade sign
    const fs = new THREE.Mesh(
      new THREE.PlaneGeometry(6, 1.2),
      new THREE.MeshStandardMaterial({ map: signTexture(['बेगुनकोडोर स्टेशन', 'BEGUNKODOR STATION']), roughness: 0.6 }),
    )
    fs.position.set(-16.4, 5.2, 18)
    fs.rotation.y = -Math.PI / 2
    g.add(fs)
    for (let i = 0; i < 14; i++) {
      const tr = new THREE.Mesh(new THREE.ConeGeometry(1.6 + Math.random(), 6 + Math.random() * 3, 6), m.foliage)
      tr.position.set(-30 - Math.random() * 25, 3, -8 + i * 4 + Math.random() * 2)
      g.add(tr)
    }
    // lamp post
    this.box(0.15, 5, 0.15, m.metal, -22, 2.5, 14, { parent: g, collide: true })
    this.lamp('street', -22, 5, 14.6, 0xffa64a, 5, 16, 0.6, true)
  }

  buildRain() {
    const count = 2600
    const pos = new Float32Array(count * 6)
    this.rainVel = new Float32Array(count)
    for (let i = 0; i < count; i++) {
      const street = i < 700
      const x = street ? -16.5 - Math.random() * 30 : 4.7 + Math.random() * 10
      const z = street ? -10 + Math.random() * 56 : -70 + Math.random() * 110
      const y = Math.random() * 12 - 1.2
      pos.set([x, y, z, x, y - 0.35, z], i * 6)
      this.rainVel[i] = 9 + Math.random() * 4
    }
    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3))
    this.rain = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: 0x8a98a8, transparent: true, opacity: 0.35 }))
    this.rain.frustumCulled = false
    this.scene.add(this.rain)
  }

  // ---------- queries ----------
  floorAt(x: number, z: number, prevY: number) {
    if (x > -3.5 && x < -0.5 && z < -46 && z > -56) return THREE.MathUtils.clamp(((-46 - z) / 10) * 5, 0, 5)
    if (x > -3.6 && x < 16.2 && z <= -56 && z > -60.2 && prevY > 2.5) return 5
    return 0
  }

  region(x: number, z: number, y: number): Region {
    if (y > 2.5 && z < -55.5) return 'bridge'
    if (x > -3.5 && x < -0.5 && z < -46 && z > -56) return 'stairs'
    if (x < -16.2) return 'street'
    if (x < -4) {
      if (z > 12 && z < 24) return 'hall'
      if (z > -6 && z < 4) return 'office'
      if (z > -24 && z < -14) return 'cctv'
      if (z > -46 && z < -34) return 'copy'
    }
    if (x > 4) return 'tracks'
    return 'platform'
  }

  isIndoor(r: Region) {
    return r === 'hall' || r === 'office' || r === 'cctv' || r === 'copy'
  }

  blocked(x: number, z: number, y: number, r = 0.2) {
    for (const c of this.colliders) {
      if (!c.enabled) continue
      if (y + 1.6 < c.minY || y > c.maxY) continue
      if (x > c.minX - r && x < c.maxX + r && z > c.minZ - r && z < c.maxZ + r) return true
    }
    return false
  }

  /** Ray-march along the ground to find free distance before a collider. */
  freeDistance(x: number, z: number, y: number, dx: number, dz: number, max: number) {
    for (let d = 0.5; d <= max; d += 0.5) {
      if (this.blocked(x + dx * d, z + dz * d, y, 0.25)) return d - 0.5
    }
    return max
  }

  // ---------- update ----------
  update(dt: number, time: number) {
    for (const key in this.doors) {
      const d = this.doors[key]
      if (d.angle !== d.target) {
        const step = d.speed * dt
        d.angle = Math.abs(d.target - d.angle) < step ? d.target : d.angle + Math.sign(d.target - d.angle) * step
        d.pivot.rotation.y = d.angle
      }
      d.collider.enabled = Math.abs(d.angle) < 0.6
    }
    for (const key in this.lamps) {
      const l = this.lamps[key]
      let f = 1
      if (l.flicker > 0) {
        l.flicker -= dt
        f = Math.random() < 0.5 ? 0.05 : 1
      } else if (l.broken) {
        f = Math.sin(time * 37) > 0.93 || Math.random() < 0.02 ? 0.1 : 1
      }
      const v = l.on ? f : 0
      l.light.intensity = l.base * v
      ;(l.tube.material as THREE.MeshStandardMaterial).emissiveIntensity = 2.2 * v
    }
    if (this.fan) this.fan.rotation.y += dt * 2.4
    // rain
    const pos = this.rain.geometry.attributes.position as THREE.BufferAttribute
    const arr = pos.array as Float32Array
    for (let i = 0; i < this.rainVel.length; i++) {
      const o = i * 6
      let y = arr[o + 1] - this.rainVel[i] * dt
      if (y < -1.2) y = 10.8
      arr[o + 1] = y
      arr[o + 4] = y - 0.35
    }
    pos.needsUpdate = true
    this.cctvMaterial.uniforms.time.value = time
  }
}
