import * as THREE from 'three'
import type { Game } from './game'
import { hud } from './hud-store'
import { paleFaceTexture, silhouetteTexture } from './textures'

const rand = (a: number, b: number) => a + Math.random() * (b - a)

type EventDef = {
  id: string
  weight: number
  available: () => boolean
  run: () => Promise<void>
}

/**
 * Paces the horror. Tracks how comfortable the player is and decides when
 * (and whether) something should happen. Sometimes the answer is "nothing".
 */
export class FearDirector {
  g: Game
  fear = 0
  enabled = false
  busy = false
  timeSinceEvent = 0
  nextDelay = 30
  lastEvent = ''
  private hudTimer = 0
  private events: EventDef[] = []
  private faceMesh: THREE.Mesh
  private shadowMesh: THREE.Mesh
  private raycaster = new THREE.Raycaster()

  // tracked signals
  playerMovement = 0
  playerSpeed = 0
  playerLookDirection = new THREE.Vector3()
  entityDistance = Infinity

  constructor(g: Game) {
    this.g = g
    this.faceMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(0.26, 0.34),
      new THREE.MeshBasicMaterial({ map: paleFaceTexture(), transparent: true, color: 0x8a8a86, depthWrite: false }),
    )
    this.faceMesh.visible = false
    g.scene.add(this.faceMesh)
    this.shadowMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(0.8, 1.6),
      new THREE.MeshBasicMaterial({ map: silhouetteTexture(), transparent: true, opacity: 0, depthWrite: false, fog: false }),
    )
    this.shadowMesh.visible = false
    g.scene.add(this.shadowMesh)

    const b = () => g.behind
    this.events = [
      { id: 'nothing', weight: 1.6, available: () => true, run: async () => {} },
      { id: 'steps', weight: 3, available: () => g.player.speed > 0.6, run: () => b().echoSteps(rand(5, 9) | 0, rand(7, 10), rand(3, 5)) },
      { id: 'breath', weight: 2, available: () => g.player.speed < 0.5, run: () => b().breathBehind() },
      { id: 'whisper', weight: 1.2, available: () => true, run: () => b().whisperBehind() },
      { id: 'hand', weight: 0.9, available: () => !g.cameraMode, run: () => b().handAtEdge() },
      { id: 'entity', weight: 1.1, available: () => true, run: () => b().entityBehind() },
      { id: 'silence', weight: 1.2, available: () => true, run: () => this.deadSilence() },
      { id: 'glimpse', weight: 1.6, available: () => g.region === 'platform', run: () => this.lampGlimpse() },
      { id: 'face', weight: 1.1, available: () => g.flashOn && (g.region === 'platform' || g.region === 'tracks'), run: () => this.flashFace() },
      { id: 'shadow', weight: 1.0, available: () => g.flashOn, run: () => this.flashShadow() },
      { id: 'flicker', weight: 1.3, available: () => true, run: () => this.flicker() },
    ]
  }

  bump(amount: number) {
    this.fear = Math.min(1, this.fear + amount)
    this.timeSinceEvent = 0
    this.scheduleNext()
  }

  private scheduleNext() {
    if (this.fear > 0.7) this.nextDelay = rand(50, 80)
    else if (this.fear < 0.25) this.nextDelay = rand(14, 26)
    else this.nextDelay = rand(26, 45)
  }

  update(dt: number) {
    const g = this.g
    this.playerSpeed = g.player.speed
    this.playerMovement += g.player.speed * dt
    g.lookDir(this.playerLookDirection)
    this.entityDistance = g.girl.visible ? g.distTo(g.girl.position) : Infinity

    if (g.player.running) this.fear += 0.004 * dt
    if (!g.flashOn && !g.isLit()) this.fear += 0.01 * dt
    else this.fear -= 0.012 * dt
    if (this.entityDistance < 6) this.fear += 0.08 * dt
    this.fear = THREE.MathUtils.clamp(this.fear, 0, 1)
    g.audio.heartbeat(this.fear, g.time)

    this.hudTimer += dt
    if (this.hudTimer > 0.25) {
      this.hudTimer = 0
      hud.set({ fear: Math.round(this.fear * 20) / 20 })
    }

    if (!this.enabled || this.busy || g.story.cutscene) return
    this.timeSinceEvent += dt
    if (this.timeSinceEvent < this.nextDelay) return
    this.trigger()
  }

  private async trigger() {
    const pool = this.events.filter((e) => e.id !== this.lastEvent && e.available())
    const total = pool.reduce((s, e) => s + e.weight, 0)
    let r = Math.random() * total
    let pick = pool[0]
    for (const e of pool) {
      r -= e.weight
      if (r <= 0) {
        pick = e
        break
      }
    }
    this.busy = true
    this.lastEvent = pick.id
    try {
      await pick.run()
    } finally {
      this.busy = false
      this.timeSinceEvent = 0
      if (pick.id !== 'nothing') this.fear = Math.min(1, this.fear + 0.12)
      this.scheduleNext()
    }
  }

  async deadSilence() {
    const g = this.g
    g.audio.setAmbient(0, 0.25)
    await g.wait(rand(5, 7))
    const p1 = g.behindPoint(9, rand(-2, 2))
    g.audio.knock({ x: p1.x, y: p1.y + 1, z: p1.z })
    await g.wait(rand(2.5, 3.5))
    const p2 = g.behindPoint(4.5, rand(-1, 1))
    g.audio.knock({ x: p2.x, y: p2.y + 1, z: p2.z }, 1)
    await g.wait(rand(4, 6))
    g.audio.setAmbient(g.ambientLevel, 5)
  }

  async flicker() {
    const g = this.g
    let best: string | null = null
    let bestD = Infinity
    for (const k in g.world.lamps) {
      const l = g.world.lamps[k]
      if (!l.on) continue
      const d = l.light.position.distanceTo(g.head())
      if (d < bestD) {
        bestD = d
        best = k
      }
    }
    if (!best || bestD > 14) return
    const l = g.world.lamps[best]
    l.flicker = rand(0.6, 1.4)
    g.audio.flicker(l.light.position)
    if (g.flashOn && Math.random() < 0.5) g.setFlashBroken(rand(0.5, 1.2))
    await g.wait(2)
  }

  /** The girl appears under a distant lamp only while it stutters back on. */
  async lampGlimpse() {
    const g = this.g
    const candidates = Object.entries(g.world.lamps).filter(([k, l]) => {
      if (!k.startsWith('p') || !l.on) return false
      const d = g.distTo(l.light.position)
      return d > 10 && d < 30
    })
    if (!candidates.length) return
    const [, lamp] = candidates[(Math.random() * candidates.length) | 0]
    const pos = new THREE.Vector3(lamp.light.position.x - 1.2, 0, lamp.light.position.z)
    lamp.on = false
    g.audio.flicker(lamp.light.position)
    await g.wait(0.6)
    g.showGirl(g.girl, pos, { mode: 'vanishOnLook', dwellNeeded: 0.35, lookAngle: 0.2, blinkVanish: true, maxTime: 12 })
    lamp.on = true
    await g.wait(0.3)
    lamp.on = false
    await g.wait(0.25)
    lamp.on = true
    await g.waitUntil(() => !g.girl.visible, 12)
    g.hideGirl(g.girl)
  }

  /** A pale face 20m out in the dark, only after the player looks away. */
  async flashFace() {
    const g = this.g
    const f = g.flatForward(new THREE.Vector3())
    const free = g.world.freeDistance(g.player.pos.x, g.player.pos.z, g.player.pos.y, f.x, f.z, 22)
    if (free < 12) return
    const dist = Math.min(20, free - 1)
    const spot = new THREE.Vector3(g.player.pos.x + f.x * dist, g.player.pos.y + 1.55, g.player.pos.z + f.z * dist)
    const turnedAway = await g.waitUntil(() => g.flatAngleTo(spot) > 1.7, 20)
    if (!turnedAway) return
    this.faceMesh.position.copy(spot)
    this.faceMesh.lookAt(g.head())
    this.faceMesh.visible = true
    let toggled = false
    const prev = g.onFlashToggle
    g.onFlashToggle = (on) => {
      prev?.(on)
      if (!on) toggled = true
    }
    const seen = await g.waitUntil(() => g.angleTo(spot) < 0.3, 25)
    if (seen) {
      let dwell = 0
      await g.waitUntil(() => {
        this.faceMesh.lookAt(g.head())
        if (g.angleTo(spot) < 0.25) dwell += 1 / 60
        return toggled || dwell > 2.6 || g.distTo(spot) < 9
      }, 30)
      if (!toggled) await g.blink()
    }
    this.faceMesh.visible = false
    g.onFlashToggle = prev
  }

  /** The girl's shadow on a wall where nobody is standing. */
  async flashShadow() {
    const g = this.g
    const dir = g.lookDir(new THREE.Vector3())
    this.raycaster.set(g.head(), dir)
    this.raycaster.far = 7
    const hits = this.raycaster.intersectObjects(g.world.staticMeshes, false)
    const hit = hits.find((h) => h.face && h.distance > 2)
    if (!hit || !hit.face) return
    const n = hit.face.normal.clone().transformDirection(hit.object.matrixWorld)
    if (Math.abs(n.y) > 0.3) return
    const tangent = new THREE.Vector3(-n.z, 0, n.x).multiplyScalar(rand(-0.4, 0.4))
    const p = hit.point.clone().add(n.clone().multiplyScalar(0.03)).add(tangent)
    p.y = g.player.pos.y + 1.0
    this.shadowMesh.position.copy(p)
    this.shadowMesh.lookAt(p.clone().add(n))
    this.shadowMesh.visible = true
    const mat = this.shadowMesh.material as THREE.MeshBasicMaterial
    for (let i = 0; i <= 10; i++) {
      mat.opacity = (i / 10) * 0.85
      await g.wait(0.04)
    }
    await g.wait(rand(1.1, 1.8))
    for (let i = 10; i >= 0; i--) {
      mat.opacity = (i / 10) * 0.85
      await g.wait(0.06)
    }
    this.shadowMesh.visible = false
  }
}

/**
 * Everything that happens behind the player. Most of the time, nothing is
 * actually there. The player should learn that turning around is dangerous.
 */
export class BehindPlayerDirector {
  g: Game
  armedScare = false
  scareDone = false
  private avoidWhisperAt = 150
  private lastAvoidWhisper = -999

  constructor(g: Game) {
    this.g = g
  }

  update(_dt: number) {
    const g = this.g
    if (!g.fear.enabled || g.story.cutscene) return

    // The player keeps checking behind — eventually, she is there.
    if (!this.scareDone && g.lookBehindSinceScare >= 6) this.armedScare = true
    if (this.armedScare && !g.girl.visible) {
      const h = g.yawHistory
      if (h.length > 6) {
        const recent = h[h.length - 1]
        const earlier = h[Math.max(0, h.length - 6)]
        const vel = Math.abs(recent.yaw - earlier.yaw) / Math.max(0.01, recent.t - earlier.t)
        if (vel > 4.5) {
          const yaw0 = h[0].yaw
          const back = new THREE.Vector3(Math.sin(yaw0), 0, Math.cos(yaw0))
          const pos = g.player.pos.clone().add(back.multiplyScalar(1.05))
          if (g.spotFree(pos)) {
            this.armedScare = false
            this.scareDone = true
            g.lookBehindSinceScare = 0
            g.showGirl(g.girl, pos, { mode: 'vanishOnLook', lookAngle: 0.5, minTime: 0.55 })
            g.wait(0.18).then(() => {
              g.audio.sting(0.8)
              g.shake(1)
              g.fear.bump(0.5)
            })
          }
        }
      }
    }

    // The player refuses to look behind.
    const sinceLook = g.time - Math.max(g.lastLookBehind, 0)
    if (sinceLook > this.avoidWhisperAt && g.time - this.lastAvoidWhisper > 300 && g.player.speed > 0.4) {
      this.lastAvoidWhisper = g.time
      const p = g.behindPoint(0.6, -0.3)
      g.audio.whisper({ x: p.x, y: p.y + 1.6, z: p.z }, 1.4, 0.7)
      g.say({ text: 'Mujhe dekhoge nahi?', translation: "Won't you look at me?", whisper: true }, 3.5)
      g.fear.bump(0.25)
    }
  }

  /** Phantom footsteps that mirror the player's rhythm and creep closer. */
  echoSteps(count: number, startDist: number, endDist: number) {
    const g = this.g
    return new Promise<void>((resolve) => {
      let n = 0
      const done = () => {
        g.stepListeners = g.stepListeners.filter((l) => l !== listener)
        resolve()
      }
      const listener = () => {
        g.wait(0.16).then(() => {
          const d = startDist + (endDist - startDist) * (n / Math.max(1, count - 1))
          const p = g.behindPoint(d, 0.2)
          g.audio.footstep({ x: p.x, y: p.y + 0.1, z: p.z }, 0.5)
          n++
          if (n >= count) done()
        })
      }
      g.stepListeners.push(listener)
      g.wait(25).then(done)
    })
  }

  /** Explicit walking steps behind a stationary player. */
  async footsteps(count: number, startDist: number, endDist: number, interval = 0.55, volume = 0.55) {
    const g = this.g
    const anchorYaw = g.player.yaw
    const back = new THREE.Vector3(Math.sin(anchorYaw), 0, Math.cos(anchorYaw))
    for (let i = 0; i < count; i++) {
      const d = startDist + (endDist - startDist) * (i / Math.max(1, count - 1))
      const p = g.player.pos.clone().add(back.clone().multiplyScalar(d))
      g.audio.footstep({ x: p.x, y: p.y + 0.1, z: p.z }, volume)
      await g.wait(interval * rand(0.92, 1.08))
    }
  }

  async running() {
    const g = this.g
    const back = new THREE.Vector3(Math.sin(g.player.yaw), 0, Math.cos(g.player.yaw))
    for (let i = 0; i < 18; i++) {
      const d = 24 - (i / 17) * 22.5
      const p = g.player.pos.clone().add(back.clone().multiplyScalar(d))
      g.audio.footstep({ x: p.x, y: p.y + 0.1, z: p.z }, 0.6 + i * 0.03)
      await g.wait(0.17 - i * 0.003)
    }
  }

  async breathBehind() {
    const g = this.g
    const p = g.behindPoint(0.7, 0.15)
    const secs = g.audio.breath({ x: p.x, y: p.y + 1.6, z: p.z }, 2, 0.55) ?? 5
    await g.wait(secs)
  }

  async whisperBehind() {
    const g = this.g
    const lines = [
      { text: 'Arjun...', translation: '' },
      { text: 'Yahin ho na?', translation: "You're here, aren't you?" },
      { text: 'Mudo mat.', translation: "Don't turn." },
      { text: 'Main yahin hoon.', translation: "I'm right here." },
    ]
    const line = lines[(Math.random() * lines.length) | 0]
    const side = Math.random() < 0.5 ? -0.35 : 0.35
    const p = g.behindPoint(0.5, side)
    g.audio.whisper({ x: p.x, y: p.y + 1.6, z: p.z }, 1.3, 0.6)
    g.say({ text: line.text, translation: line.translation || undefined, whisper: true }, 3)
    await g.wait(3)
  }

  async handAtEdge() {
    const g = this.g
    hud.set({ hand: true })
    await g.wait(0.42)
    hud.set({ hand: false })
    await g.wait(2)
  }

  /** She stands behind the player. Turning to face her removes her. */
  async entityBehind() {
    const g = this.g
    const pos = g.behindPoint(rand(1.6, 2.6), rand(-0.4, 0.4))
    if (!g.spotFree(pos)) return
    g.showGirl(g.girl, pos, { mode: 'vanishOnLook', lookAngle: 0.45, maxTime: rand(6, 10) })
    if (Math.random() < 0.5) g.audio.breath({ x: pos.x, y: pos.y + 1.55, z: pos.z }, 1, 0.3)
    await g.waitUntil(() => !g.girl.visible, 12)
    g.hideGirl(g.girl)
  }
}
